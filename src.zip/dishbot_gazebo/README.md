# dishbot_gazebo

Gazebo restaurant environment, object models, waypoints, and simulation launch files.

## Contents

- `worlds/restaurant.world`: restaurant layout with walls, floor, lights, washing room, six tables, chairs, plates, and simple decor.
- `models/dishbot_table`: static restaurant table with low collection ledges for arm-based collection tests.
- `models/dishbot_chair`: static dining chair.
- `models/dishbot_plate`: dynamic low-mass plate with conservative friction/contact settings.
- `config/restaurant_waypoints.yaml`: semantic approach, collect, plate, and return poses.
- `launch/spawn_dishbot.launch.py`: publishes `robot_description` and spawns the robot in Gazebo.
- `launch/restaurant_sim.launch.py`: starts Gazebo with the restaurant world and spawns Dishbot in the washing room.

## Run

```bash
cd /home/ygl/zidong
colcon build
source install/setup.bash
ros2 launch dishbot_gazebo restaurant_sim.launch.py
```

This launch starts Gazebo, spawns Dishbot, starts `robot_state_publisher`, and starts the arm collection action server by default.

Headless/smoke-test style:

```bash
ros2 launch dishbot_gazebo restaurant_sim.launch.py gui:=false
```

To start Gazebo without the control node:

```bash
ros2 launch dishbot_gazebo restaurant_sim.launch.py start_control:=false
```

## Waypoint Convention

The table collection poses are aligned so the robot faces the plate with its front arm:

- `table_1` to `table_3`: approach from the south, yaw `+1.5708`.
- `table_4` to `table_6`: approach from the north, yaw `-1.5708`.
- `dishwashing_room.return_pose`: `(-4.10, 2.25, 0.0)`.

The plates are placed on low collection ledges rather than the main tabletop. This keeps the staged arm grasp, dump, and empty-plate storage loop reachable by the current robot geometry.

## Current Stage

Stage 3 provides the world and spawn chain. Driving, Nav2, pusher action control, and task orchestration are implemented in later stages.
