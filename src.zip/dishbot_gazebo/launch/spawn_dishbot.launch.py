from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import Command, LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    x = LaunchConfiguration('x')
    y = LaunchConfiguration('y')
    z = LaunchConfiguration('z')
    yaw = LaunchConfiguration('yaw')
    enable_diff_drive = LaunchConfiguration('enable_diff_drive')

    description_pkg = FindPackageShare('dishbot_description')
    xacro_file = PathJoinSubstitution([description_pkg, 'urdf', 'dishbot.urdf.xacro'])

    robot_description = {
        'robot_description': Command([
            'xacro ',
            xacro_file,
            ' enable_diff_drive:=',
            enable_diff_drive,
        ]),
        'use_sim_time': True,
    }

    return LaunchDescription([
        DeclareLaunchArgument('x', default_value='-4.10', description='Initial robot x position.'),
        DeclareLaunchArgument('y', default_value='2.25', description='Initial robot y position.'),
        DeclareLaunchArgument('z', default_value='0.0', description='Initial robot z position.'),
        DeclareLaunchArgument('yaw', default_value='0.0', description='Initial robot yaw.'),
        DeclareLaunchArgument(
            'enable_diff_drive',
            default_value='true',
            description='Load Gazebo diff drive plugin in the robot model.',
        ),
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[robot_description],
        ),
        Node(
            package='gazebo_ros',
            executable='spawn_entity.py',
            name='spawn_dishbot',
            output='screen',
            arguments=[
                '-topic', 'robot_description',
                '-entity', 'dishbot',
                '-x', x,
                '-y', y,
                '-z', z,
                '-Y', yaw,
            ],
        ),
    ])
