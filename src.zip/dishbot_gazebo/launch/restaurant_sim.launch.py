from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, SetEnvironmentVariable
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    gui = LaunchConfiguration('gui')
    paused = LaunchConfiguration('paused')
    verbose = LaunchConfiguration('verbose')
    start_control = LaunchConfiguration('start_control')
    use_cmd_vel_bridge = LaunchConfiguration('use_cmd_vel_bridge')
    enable_diff_drive = LaunchConfiguration('enable_diff_drive')

    gazebo_pkg = FindPackageShare('dishbot_gazebo')
    gazebo_ros_pkg = FindPackageShare('gazebo_ros')
    world_path = PathJoinSubstitution([gazebo_pkg, 'worlds', 'restaurant.world'])
    models_path = PathJoinSubstitution([gazebo_pkg, 'models'])

    gazebo_launch = PathJoinSubstitution([gazebo_ros_pkg, 'launch', 'gazebo.launch.py'])
    spawn_launch = PathJoinSubstitution([gazebo_pkg, 'launch', 'spawn_dishbot.launch.py'])
    control_launch = PathJoinSubstitution([
        FindPackageShare('dishbot_control'),
        'launch',
        'control.launch.py',
    ])

    return LaunchDescription([
        DeclareLaunchArgument('gui', default_value='true', description='Start Gazebo client GUI.'),
        DeclareLaunchArgument('paused', default_value='false', description='Start simulation paused.'),
        DeclareLaunchArgument('verbose', default_value='false', description='Enable verbose Gazebo output.'),
        DeclareLaunchArgument(
            'start_control',
            default_value='true',
            description='Start Dishbot control nodes with the simulation.',
        ),
        DeclareLaunchArgument(
            'use_cmd_vel_bridge',
            default_value='true',
            description='Start fallback bridge that moves the robot with /set_entity_state.',
        ),
        DeclareLaunchArgument(
            'enable_diff_drive',
            default_value='false',
            description='Load Gazebo diff drive plugin. Keep false when using cmd_vel bridge.',
        ),
        SetEnvironmentVariable(name='GAZEBO_MODEL_PATH', value=models_path),
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(gazebo_launch),
            launch_arguments={
                'world': world_path,
                'gui': gui,
                'pause': paused,
                'verbose': verbose,
            }.items(),
        ),
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(spawn_launch),
            launch_arguments={
                'x': '-4.45',
                'y': '2.25',
                'z': '0.0',
                'yaw': '0.0',
                'enable_diff_drive': enable_diff_drive,
            }.items(),
        ),
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(control_launch),
            condition=IfCondition(start_control),
            launch_arguments={
                'use_cmd_vel_bridge': use_cmd_vel_bridge,
            }.items(),
        ),
    ])
