# dishbot_description

Robot URDF/Xacro, RViz configuration, and description launch files for the restaurant dish collection robot.

## Files

- `urdf/dishbot.urdf.xacro`: top-level robot model.
- `urdf/materials.xacro`: shared visual materials.
- `urdf/mechanism.xacro`: wheel, storage bay, and plate-handling arm macros.
- `urdf/sensors.xacro`: LiDAR, camera, and IMU links.
- `urdf/gazebo_plugins.xacro`: Gazebo drive and sensor plugin configuration.
- `launch/display.launch.py`: RViz display launch.
- `rviz/dishbot_display.rviz`: RViz model and TF view.

## Check

```bash
cd /home/ygl/zidong
colcon build --packages-select dishbot_description
source install/setup.bash
ros2 launch dishbot_description display.launch.py
```

Use the joint state publisher GUI to inspect the fixed arm base and stowed forearm on top of the robot.
