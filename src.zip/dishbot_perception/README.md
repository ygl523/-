# dishbot_perception

Plate perception package for simulation-truth and camera-based detection.

Stage 1 contains the package scaffold. Later stages will publish `dishbot_msgs/msg/PlatePose` and add a simple camera fallback interface.
