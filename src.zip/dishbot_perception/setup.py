from setuptools import setup

package_name = 'dishbot_perception'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml', 'README.md']),
        ('share/' + package_name + '/launch', ['launch/perception.launch.py']),
        ('share/' + package_name + '/config', ['config/perception.yaml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Dishbot Maintainers',
    maintainer_email='dishbot@example.com',
    description='Plate localization nodes for Dishbot.',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'plate_pose_publisher = dishbot_perception.plate_pose_publisher:main',
        ],
    },
)
