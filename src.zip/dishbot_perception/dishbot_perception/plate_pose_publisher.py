import rclpy
from rclpy.node import Node


class PlatePosePublisher(Node):
    def __init__(self):
        super().__init__('plate_pose_publisher')
        self.get_logger().info('Plate pose publisher scaffold is running.')


def main(args=None):
    rclpy.init(args=args)
    node = PlatePosePublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
