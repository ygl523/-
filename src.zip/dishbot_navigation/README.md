# dishbot_navigation

Nav2 parameters, maps, waypoint loading, and navigation launch files.

Stage 1 contains the package scaffold. Later stages will add static map assets and table navigation behavior.
