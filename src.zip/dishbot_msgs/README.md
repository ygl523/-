# dishbot_msgs

Custom messages, services, and actions shared by the Dishbot packages.

Interfaces included in stage 1:

- `PlatePose.msg`
- `TableStatus.msg`
- `SetTableTarget.srv`
- `CollectDish.action`
- `GoToTable.action`
- `CycleCollect.action`
