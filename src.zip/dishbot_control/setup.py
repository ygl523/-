from setuptools import setup

package_name = 'dishbot_control'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml', 'README.md']),
        ('share/' + package_name + '/launch', ['launch/control.launch.py']),
        ('share/' + package_name + '/config', ['config/control.yaml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Dishbot Maintainers',
    maintainer_email='dishbot@example.com',
    description='Drive and pusher control nodes for Dishbot.',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'pusher_controller_node = dishbot_control.pusher_controller_node:main',
            'gazebo_cmd_vel_bridge = dishbot_control.gazebo_cmd_vel_bridge:main',
            'drive_test = dishbot_control.drive_test:main',
            'collect_dish_test = dishbot_control.collect_dish_test:main',
        ],
    },
)
