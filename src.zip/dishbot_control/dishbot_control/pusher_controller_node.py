import math
import time

import rclpy
from builtin_interfaces.msg import Duration, Time
from dishbot_msgs.action import CollectDish
from gazebo_msgs.msg import EntityState, ModelStates
from gazebo_msgs.srv import ApplyJointEffort, GetJointProperties, SetEntityState
from nav_msgs.msg import Odometry
from rclpy.action import ActionServer, CancelResponse, GoalResponse
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from std_msgs.msg import Float64
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint


def yaw_from_quaternion(q):
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


def quaternion_from_yaw(yaw):
    half = yaw * 0.5
    return 0.0, 0.0, math.sin(half), math.cos(half)


def quaternion_from_rpy(roll, pitch, yaw):
    cr = math.cos(roll * 0.5)
    sr = math.sin(roll * 0.5)
    cp = math.cos(pitch * 0.5)
    sp = math.sin(pitch * 0.5)
    cy = math.cos(yaw * 0.5)
    sy = math.sin(yaw * 0.5)
    qx = sr * cp * cy - cr * sp * sy
    qy = cr * sp * cy + sr * cp * sy
    qz = cr * cp * sy - sr * sp * cy
    qw = cr * cp * cy + sr * sp * sy
    return qx, qy, qz, qw


class PusherControllerNode(Node):
    """CollectDish action server backed by a visible Gazebo arm sequence."""

    def __init__(self):
        super().__init__('pusher_controller_node')
        self.callback_group = ReentrantCallbackGroup()

        self.declare_parameter('front_pusher_joint', 'front_pusher_joint')
        self.declare_parameter('joint_name_candidates', [
            'dishbot::front_pusher_joint',
            'front_pusher_joint',
            'dishbot::base_link::front_pusher_joint',
        ])
        self.declare_parameter('extension_m', 0.32)
        self.declare_parameter('retracted_m', 0.0)
        self.declare_parameter('position_tolerance_m', 0.015)
        self.declare_parameter('extension_effort_n', 18.0)
        self.declare_parameter('retraction_effort_n', -16.0)
        self.declare_parameter('hold_effort_n', 2.0)
        self.declare_parameter('effort_step_s', 0.12)
        self.declare_parameter('extend_timeout_s', 8.0)
        self.declare_parameter('retract_timeout_s', 8.0)
        self.declare_parameter('hold_s', 1.0)
        self.declare_parameter('control_mode', 'trajectory')
        self.declare_parameter('trajectory_topic', '/joint_trajectory')
        self.declare_parameter('trajectory_joint_name', 'front_pusher_joint')
        self.declare_parameter('trajectory_move_s', 4.0)
        self.declare_parameter('pusher_base_frame', 'dishbot::base_link')
        self.declare_parameter('pusher_carriage_entity', 'dishbot::front_pusher_carriage_link')
        self.declare_parameter('pusher_plate_entity', 'dishbot::front_pusher_plate_link')
        self.declare_parameter('pusher_visual_entity', 'dishbot_gripper_visual')
        self.declare_parameter('arm_upper_visual_entity', 'dishbot_arm_upper_visual')
        self.declare_parameter('arm_forearm_visual_entity', 'dishbot_arm_forearm_visual')
        self.declare_parameter('robot_model_name', 'dishbot')
        self.declare_parameter('plate_entity_prefix', 'plate_')
        self.declare_parameter('waste_entity_prefix', 'food_waste_')
        self.declare_parameter('storage_plate_x', -0.18)
        self.declare_parameter('storage_plate_y', 0.0)
        self.declare_parameter('storage_plate_z', 0.665)
        self.declare_parameter('waste_bin_x', -0.07)
        self.declare_parameter('waste_bin_y', -0.31)
        self.declare_parameter('waste_bin_z', 0.305)
        self.declare_parameter('gripper_retracted_forward_m', 0.28)
        self.declare_parameter('gripper_tray_forward_m', 0.20)
        self.declare_parameter('gripper_target_forward_offset_m', 0.0)
        self.declare_parameter('gripper_target_lateral_offset_m', 0.0)
        self.declare_parameter('hide_pusher_when_idle', True)
        self.declare_parameter('require_pose_check', False)
        self.declare_parameter('max_collect_linear_speed_mps', 0.03)
        self.declare_parameter('max_collect_angular_speed_rps', 0.05)
        self.declare_parameter('arm_stowed_forward_m', 0.52)
        self.declare_parameter('arm_stowed_z_m', 1.02)
        self.declare_parameter('arm_shoulder_forward_m', 0.06)
        self.declare_parameter('arm_shoulder_lateral_m', 0.0)
        self.declare_parameter('arm_shoulder_z_m', 0.845)
        self.declare_parameter('arm_upper_length_m', 0.44)
        self.declare_parameter('arm_forearm_length_m', 0.44)
        self.declare_parameter('arm_hover_z_m', 0.84)
        self.declare_parameter('arm_grasp_clearance_m', 0.135)
        self.declare_parameter('arm_payload_clearance_m', 0.095)
        self.declare_parameter('arm_payload_forward_offset_m', 0.11)
        self.declare_parameter('arm_pregrasp_backoff_m', 0.24)
        self.declare_parameter('arm_motion_step_s', 0.05)
        self.declare_parameter('arm_segment_s', 1.1)
        self.declare_parameter('arm_dump_s', 1.4)
        self.declare_parameter('arm_place_s', 0.9)

        self.joint_name = self.get_parameter('front_pusher_joint').value
        self.joint_name_candidates = list(self.get_parameter('joint_name_candidates').value)
        self.extension_m = float(self.get_parameter('extension_m').value)
        self.retracted_m = float(self.get_parameter('retracted_m').value)
        self.position_tolerance_m = float(self.get_parameter('position_tolerance_m').value)
        self.extension_effort_n = float(self.get_parameter('extension_effort_n').value)
        self.retraction_effort_n = float(self.get_parameter('retraction_effort_n').value)
        self.hold_effort_n = float(self.get_parameter('hold_effort_n').value)
        self.effort_step_s = float(self.get_parameter('effort_step_s').value)
        self.extend_timeout_s = float(self.get_parameter('extend_timeout_s').value)
        self.retract_timeout_s = float(self.get_parameter('retract_timeout_s').value)
        self.hold_s = float(self.get_parameter('hold_s').value)
        self.control_mode = self.get_parameter('control_mode').value
        self.trajectory_joint_name = self.get_parameter('trajectory_joint_name').value
        self.trajectory_move_s = float(self.get_parameter('trajectory_move_s').value)
        self.pusher_base_frame = self.get_parameter('pusher_base_frame').value
        self.pusher_carriage_entity = self.get_parameter('pusher_carriage_entity').value
        self.pusher_plate_entity = self.get_parameter('pusher_plate_entity').value
        self.pusher_visual_entity = self.get_parameter('pusher_visual_entity').value
        self.arm_upper_visual_entity = self.get_parameter('arm_upper_visual_entity').value
        self.arm_forearm_visual_entity = self.get_parameter('arm_forearm_visual_entity').value
        self.robot_model_name = self.get_parameter('robot_model_name').value
        self.plate_entity_prefix = self.get_parameter('plate_entity_prefix').value
        self.waste_entity_prefix = self.get_parameter('waste_entity_prefix').value
        self.storage_plate_x = float(self.get_parameter('storage_plate_x').value)
        self.storage_plate_y = float(self.get_parameter('storage_plate_y').value)
        self.storage_plate_z = float(self.get_parameter('storage_plate_z').value)
        self.waste_bin_x = float(self.get_parameter('waste_bin_x').value)
        self.waste_bin_y = float(self.get_parameter('waste_bin_y').value)
        self.waste_bin_z = float(self.get_parameter('waste_bin_z').value)
        self.gripper_retracted_forward_m = float(
            self.get_parameter('gripper_retracted_forward_m').value
        )
        self.gripper_tray_forward_m = float(
            self.get_parameter('gripper_tray_forward_m').value
        )
        self.gripper_target_forward_offset_m = float(
            self.get_parameter('gripper_target_forward_offset_m').value
        )
        self.gripper_target_lateral_offset_m = float(
            self.get_parameter('gripper_target_lateral_offset_m').value
        )
        self.hide_pusher_when_idle = bool(self.get_parameter('hide_pusher_when_idle').value)
        self.active_table_id = ''
        self.require_pose_check = bool(self.get_parameter('require_pose_check').value)
        self.max_collect_linear_speed_mps = float(
            self.get_parameter('max_collect_linear_speed_mps').value
        )
        self.max_collect_angular_speed_rps = float(
            self.get_parameter('max_collect_angular_speed_rps').value
        )
        self.arm_stowed_forward_m = float(self.get_parameter('arm_stowed_forward_m').value)
        self.arm_stowed_z_m = float(self.get_parameter('arm_stowed_z_m').value)
        self.arm_shoulder_forward_m = float(
            self.get_parameter('arm_shoulder_forward_m').value
        )
        self.arm_shoulder_lateral_m = float(
            self.get_parameter('arm_shoulder_lateral_m').value
        )
        self.arm_shoulder_z_m = float(self.get_parameter('arm_shoulder_z_m').value)
        self.arm_upper_length_m = float(self.get_parameter('arm_upper_length_m').value)
        self.arm_forearm_length_m = float(self.get_parameter('arm_forearm_length_m').value)
        self.arm_hover_z_m = float(self.get_parameter('arm_hover_z_m').value)
        self.arm_grasp_clearance_m = float(
            self.get_parameter('arm_grasp_clearance_m').value
        )
        self.arm_payload_clearance_m = float(
            self.get_parameter('arm_payload_clearance_m').value
        )
        self.arm_payload_forward_offset_m = float(
            self.get_parameter('arm_payload_forward_offset_m').value
        )
        self.arm_pregrasp_backoff_m = float(
            self.get_parameter('arm_pregrasp_backoff_m').value
        )
        self.arm_motion_step_s = float(self.get_parameter('arm_motion_step_s').value)
        self.arm_segment_s = float(self.get_parameter('arm_segment_s').value)
        self.arm_dump_s = float(self.get_parameter('arm_dump_s').value)
        self.arm_place_s = float(self.get_parameter('arm_place_s').value)

        self.latest_odom = None
        self.latest_robot_pose = None
        self.model_poses = {}
        self.collection_start_plate_pose = None
        self.collection_start_waste_pose = None
        self.idle_gripper_timer = self.create_timer(
            0.10,
            self._update_idle_gripper_visual,
            callback_group=self.callback_group,
        )
        self.create_subscription(
            Odometry,
            '/odom',
            self._odom_callback,
            qos_profile_sensor_data,
            callback_group=self.callback_group,
        )
        self.create_subscription(
            ModelStates,
            '/model_states',
            self._model_states_callback,
            10,
            callback_group=self.callback_group,
        )
        self.command_publisher = self.create_publisher(
            Float64,
            '/dishbot/front_pusher/command',
            10,
        )
        self.trajectory_publisher = self.create_publisher(
            JointTrajectory,
            self.get_parameter('trajectory_topic').value,
            10,
        )
        self.apply_effort_client = self.create_client(
            ApplyJointEffort,
            '/apply_joint_effort',
            callback_group=self.callback_group,
        )
        self.get_joint_client = self.create_client(
            GetJointProperties,
            '/get_joint_properties',
            callback_group=self.callback_group,
        )
        self.set_entity_state_client = self.create_client(
            SetEntityState,
            '/set_entity_state',
            callback_group=self.callback_group,
        )
        self.action_server = ActionServer(
            self,
            CollectDish,
            '/collect_dish',
            execute_callback=self._execute_collect,
            goal_callback=self._goal_callback,
            cancel_callback=self._cancel_callback,
            callback_group=self.callback_group,
        )
        self.get_logger().info(
            'CollectDish action server ready with visible arm grasp sequence.'
        )

    def _odom_callback(self, msg):
        self.latest_odom = msg

    def _model_states_callback(self, msg):
        self.model_poses = {name: pose for name, pose in zip(msg.name, msg.pose)}
        try:
            index = msg.name.index(self.robot_model_name)
        except ValueError:
            return
        self.latest_robot_pose = msg.pose[index]

    def _goal_callback(self, goal_request):
        if not goal_request.table_id:
            self.get_logger().warn('Rejecting CollectDish goal with empty table_id.')
            return GoalResponse.REJECT
        return GoalResponse.ACCEPT

    def _cancel_callback(self, _goal_handle):
        self.get_logger().warn('CollectDish cancel requested; returning arm to stowed pose.')
        return CancelResponse.ACCEPT

    def _execute_collect(self, goal_handle):
        feedback = CollectDish.Feedback()
        result = CollectDish.Result()

        if self.require_pose_check and not self._robot_is_stopped():
            result.success = False
            result.message = 'Robot is not stopped near collection pose.'
            goal_handle.abort()
            return result

        if self.control_mode == 'entity_state':
            if not self.set_entity_state_client.wait_for_service(timeout_sec=5.0):
                result.success = False
                result.message = 'Gazebo /set_entity_state service is unavailable.'
                goal_handle.abort()
                return result
            return self._execute_arm_collect(goal_handle, feedback, result)
        elif self.control_mode == 'trajectory':
            self.get_logger().info(
                f'Using trajectory control for {self.trajectory_joint_name}.'
            )
        elif not self._wait_for_gazebo_services(timeout_s=5.0):
            result.success = False
            result.message = 'Gazebo joint services are unavailable.'
            goal_handle.abort()
            return result
        result.success = False
        result.message = 'Only entity_state arm control is supported for this demo.'
        goal_handle.abort()
        return result

    def _execute_arm_collect(self, goal_handle, feedback, result):
        """Run a deterministic arm sequence with explicit payload poses.

        The plate and waste models are kinematic in this demo world, so the action
        owns their poses while the arm is manipulating them. The path keeps the
        gripper above the table before descent and keeps the plate above tray/bin
        heights while moving, avoiding obvious visual interpenetration.
        """
        try:
            self.active_table_id = goal_handle.request.table_id
            plate_name = f'{self.plate_entity_prefix}{self.active_table_id}'
            waste_name = f'{self.waste_entity_prefix}{self.active_table_id}'
            self.collection_start_plate_pose = self._entity_pose(plate_name)
            self.collection_start_waste_pose = self._entity_pose(waste_name)
            if self.collection_start_plate_pose is None:
                result.success = False
                result.message = f'Could not find {plate_name} in Gazebo.'
                goal_handle.abort()
                return result
            if self.latest_robot_pose is None:
                result.success = False
                result.message = 'Robot pose from /model_states is unavailable.'
                goal_handle.abort()
                return result

            yaw = yaw_from_quaternion(self.latest_robot_pose.orientation)
            plate_xyz = (
                self.collection_start_plate_pose.position.x,
                self.collection_start_plate_pose.position.y,
                self.collection_start_plate_pose.position.z,
            )
            forward = (math.cos(yaw), math.sin(yaw), 0.0)
            hover_xyz = self._wrist_xyz_for_payload(
                plate_xyz,
                yaw,
                self._world_z(self.arm_hover_z_m),
            )
            pregrasp_hover_xyz = (
                plate_xyz[0] - self.arm_pregrasp_backoff_m * forward[0],
                plate_xyz[1] - self.arm_pregrasp_backoff_m * forward[1],
                self._world_z(self.arm_hover_z_m),
            )
            pregrasp_low_xyz = (
                pregrasp_hover_xyz[0],
                pregrasp_hover_xyz[1],
                plate_xyz[2] + self.arm_grasp_clearance_m,
            )
            grasp_xyz = (
                plate_xyz[0] - self.arm_payload_forward_offset_m * forward[0],
                plate_xyz[1] - self.arm_payload_forward_offset_m * forward[1],
                plate_xyz[2] + self.arm_grasp_clearance_m,
            )
            stowed_xyz = self._robot_relative_xyz(
                self.arm_stowed_forward_m,
                0.0,
                self._world_z(self.arm_stowed_z_m),
                yaw,
            )
            bin_xyz = self._robot_relative_xyz(
                self.waste_bin_x,
                self.waste_bin_y,
                self._safe_payload_world_z(self.waste_bin_z + 0.44),
                yaw,
            )
            bin_xyz = self._wrist_xyz_for_payload(bin_xyz, yaw, bin_xyz[2])
            storage_hover_xyz = self._robot_relative_xyz(
                self.storage_plate_x,
                self.storage_plate_y,
                self._safe_payload_world_z(self.storage_plate_z + 0.22),
                yaw,
            )
            storage_hover_xyz = self._wrist_xyz_for_payload(
                storage_hover_xyz,
                yaw,
                storage_hover_xyz[2],
            )
            storage_place_xyz = self._robot_relative_xyz(
                self.storage_plate_x,
                self.storage_plate_y,
                self._safe_payload_world_z(self.storage_plate_z + self.arm_payload_clearance_m),
                yaw,
            )
            storage_place_xyz = self._wrist_xyz_for_payload(
                storage_place_xyz,
                yaw,
                storage_place_xyz[2],
            )
            safe_lift_xyz = (
                stowed_xyz[0],
                stowed_xyz[1],
                max(stowed_xyz[2] + 0.14, hover_xyz[2] + 0.08, self._world_z(1.18)),
            )
            storage_vertical_clear_xyz = (
                storage_hover_xyz[0],
                storage_hover_xyz[1],
                safe_lift_xyz[2],
            )
            return_side_clear_xyz = self._robot_relative_xyz(
                self.storage_plate_x,
                -0.42,
                safe_lift_xyz[2],
                yaw,
            )
            return_front_side_xyz = self._robot_relative_xyz(
                self.arm_stowed_forward_m,
                -0.42,
                safe_lift_xyz[2],
                yaw,
            )
            return_front_center_xyz = (
                stowed_xyz[0],
                stowed_xyz[1],
                safe_lift_xyz[2],
            )
            bin_clear_xyz = (
                bin_xyz[0],
                bin_xyz[1],
                safe_lift_xyz[2],
            )
            storage_outboard_clear_xyz = self._robot_relative_xyz(
                self.storage_plate_x,
                -0.46,
                safe_lift_xyz[2],
                yaw,
            )
            storage_center_clear_xyz = (
                storage_hover_xyz[0],
                storage_hover_xyz[1],
                safe_lift_xyz[2],
            )

            self._set_arm_state(stowed_xyz, yaw, mode='open')
            self._publish_feedback(goal_handle, feedback, 'arm_reaching_plate', 0.08)
            if not self._animate_arm_segment(
                goal_handle, feedback, stowed_xyz, safe_lift_xyz, yaw, 0.08, 0.14,
                'arm_lifting_clear_of_sensors', payload='table', duration_s=0.55,
            ):
                return self._abort_arm_collect(goal_handle, result, 'Arm motion was canceled.')
            if not self._animate_arm_segment(
                goal_handle, feedback, safe_lift_xyz, pregrasp_hover_xyz, yaw, 0.14, 0.22,
                'arm_reaching_plate', payload='table',
            ):
                return self._abort_arm_collect(goal_handle, result, 'Arm motion was canceled.')
            if not self._animate_arm_segment(
                goal_handle, feedback, pregrasp_hover_xyz, pregrasp_low_xyz, yaw, 0.22, 0.29,
                'arm_lowering_outside_table', payload='table', duration_s=0.75,
            ):
                return self._abort_arm_collect(goal_handle, result, 'Arm motion was canceled.')
            if not self._animate_arm_segment(
                goal_handle, feedback, pregrasp_low_xyz, grasp_xyz, yaw, 0.29, 0.34,
                'arm_sliding_to_plate_rim', payload='table', duration_s=0.65,
            ):
                return self._abort_arm_collect(goal_handle, result, 'Arm motion was canceled.')

            self._publish_feedback(goal_handle, feedback, 'grasping_plate', 0.38)
            self._set_arm_state(grasp_xyz, yaw, mode='closed')
            for _ in range(6):
                grasped_plate_xyz = self._payload_xyz_from_arm(grasp_xyz, yaw)
                self._set_plate_attached_state(grasped_plate_xyz, yaw, pitch=0.0)
                self._set_waste_attached_state(self._waste_xyz_from_plate(grasped_plate_xyz))
                time.sleep(0.05)

            if not self._animate_arm_segment(
                goal_handle, feedback, grasp_xyz, hover_xyz, yaw, 0.38, 0.50,
                'lifting_plate', payload='attached',
            ):
                return self._abort_arm_collect(goal_handle, result, 'Arm motion was canceled.')
            if not self._animate_arm_segment(
                goal_handle, feedback, hover_xyz, bin_xyz, yaw, 0.50, 0.66,
                'moving_to_waste_bin', payload='attached',
            ):
                return self._abort_arm_collect(goal_handle, result, 'Arm motion was canceled.')
            if not self._animate_dump(goal_handle, feedback, bin_xyz, yaw):
                return self._abort_arm_collect(goal_handle, result, 'Arm motion was canceled.')
            if not self._animate_arm_segment(
                goal_handle, feedback, bin_xyz, bin_clear_xyz, yaw, 0.78, 0.815,
                'lifting_empty_plate_from_bin', payload='plate_only', duration_s=0.55,
            ):
                return self._abort_arm_collect(goal_handle, result, 'Arm motion was canceled.')
            if not self._animate_arm_segment(
                goal_handle, feedback, bin_clear_xyz, storage_outboard_clear_xyz, yaw, 0.815, 0.855,
                'moving_empty_plate_outboard', payload='plate_only', duration_s=0.75,
            ):
                return self._abort_arm_collect(goal_handle, result, 'Arm motion was canceled.')
            if not self._animate_arm_segment(
                goal_handle, feedback, storage_outboard_clear_xyz, storage_center_clear_xyz, yaw, 0.855, 0.88,
                'moving_empty_plate_above_storage', payload='plate_only', duration_s=0.55,
            ):
                return self._abort_arm_collect(goal_handle, result, 'Arm motion was canceled.')
            if not self._animate_arm_segment(
                goal_handle, feedback, storage_center_clear_xyz, storage_hover_xyz, yaw, 0.88, 0.905,
                'lowering_empty_plate_to_storage_hover', payload='plate_only', duration_s=0.45,
            ):
                return self._abort_arm_collect(goal_handle, result, 'Arm motion was canceled.')
            if not self._animate_arm_segment(
                goal_handle, feedback, storage_hover_xyz, storage_place_xyz, yaw, 0.905, 0.94,
                'placing_empty_plate', payload='plate_only', duration_s=max(self.arm_place_s, 1.1),
            ):
                return self._abort_arm_collect(goal_handle, result, 'Arm motion was canceled.')

            self._set_plate_attached_state(
                self._payload_xyz_from_arm(storage_place_xyz, yaw), yaw, pitch=0.0,
            )
            self._set_arm_state(storage_place_xyz, yaw, mode='open')
            time.sleep(0.25)
            if not self._animate_arm_segment(
                goal_handle, feedback, storage_place_xyz, storage_hover_xyz, yaw, 0.94, 0.965,
                'arm_lifting_clear_of_storage', payload='placed', duration_s=0.55,
            ):
                return self._abort_arm_collect(goal_handle, result, 'Arm motion was canceled.')
            if not self._animate_arm_segment(
                goal_handle, feedback, storage_hover_xyz, storage_vertical_clear_xyz, yaw, 0.965, 0.974,
                'arm_rising_above_storage', payload='placed', duration_s=0.45,
            ):
                return self._abort_arm_collect(goal_handle, result, 'Arm motion was canceled.')
            if not self._animate_arm_segment(
                goal_handle, feedback, storage_vertical_clear_xyz, return_side_clear_xyz, yaw, 0.974, 0.982,
                'arm_moving_outboard', payload='placed', duration_s=0.55,
            ):
                return self._abort_arm_collect(goal_handle, result, 'Arm motion was canceled.')
            if not self._animate_arm_segment(
                goal_handle, feedback, return_side_clear_xyz, return_front_side_xyz, yaw, 0.982, 0.988,
                'arm_returning_home_outboard', payload='placed', duration_s=0.60,
            ):
                return self._abort_arm_collect(goal_handle, result, 'Arm motion was canceled.')
            if not self._animate_arm_segment(
                goal_handle, feedback, return_front_side_xyz, return_front_center_xyz, yaw, 0.988, 0.994,
                'arm_centering_to_dock', payload='placed', duration_s=0.45,
            ):
                return self._abort_arm_collect(goal_handle, result, 'Arm motion was canceled.')
            if not self._animate_arm_segment(
                goal_handle, feedback, return_front_center_xyz, stowed_xyz, yaw, 0.994, 0.998,
                'arm_docking', payload='placed', duration_s=0.40,
            ):
                return self._abort_arm_collect(goal_handle, result, 'Arm motion was canceled.')
            self._publish_feedback(goal_handle, feedback, 'complete', 1.0)
            result.success = True
            result.message = f'Collected, dumped, and stored empty plate for {self.active_table_id}.'
            self.active_table_id = ''
            self.collection_start_plate_pose = None
            self.collection_start_waste_pose = None
            goal_handle.succeed()
            return result
        except Exception as exc:  # noqa: BLE001
            self.get_logger().error(f'Arm CollectDish failed: {exc}')
            result.success = False
            result.message = f'Arm CollectDish exception: {exc}'
            self.active_table_id = ''
            self.collection_start_plate_pose = None
            self.collection_start_waste_pose = None
            goal_handle.abort()
            return result

    def _abort_arm_collect(self, goal_handle, result, message):
        self._safe_retract_arm()
        result.success = False
        result.message = message
        goal_handle.abort()
        return result

    def _robot_is_stopped(self):
        if self.latest_odom is None:
            return False
        twist = self.latest_odom.twist.twist
        linear_speed = math.hypot(twist.linear.x, twist.linear.y)
        angular_speed = abs(twist.angular.z)
        return (
            linear_speed <= self.max_collect_linear_speed_mps
            and angular_speed <= self.max_collect_angular_speed_rps
        )

    def _wait_for_gazebo_services(self, timeout_s):
        deadline = time.monotonic() + timeout_s
        while rclpy.ok() and time.monotonic() < deadline:
            effort_ready = self.apply_effort_client.wait_for_service(timeout_sec=0.2)
            joint_ready = self.get_joint_client.wait_for_service(timeout_sec=0.2)
            if effort_ready and joint_ready:
                return True
        return False

    def _select_working_joint_name(self):
        candidates = []
        for name in [self.joint_name] + self.joint_name_candidates:
            if name and name not in candidates:
                candidates.append(name)

        original_name = self.joint_name
        for candidate in candidates:
            self.joint_name = candidate
            position = self._get_joint_position(log_failure=False)
            if position is not None:
                if candidate != original_name:
                    self.get_logger().info(
                        f'Using Gazebo joint name {candidate} for front pusher.'
                    )
                return True
        self.joint_name = original_name
        self.get_logger().error(f'No usable pusher joint found. Tried: {candidates}')
        return False

    def _move_to_position(
        self,
        goal_handle,
        target,
        effort,
        timeout_s,
        state,
        progress_start,
        progress_end,
    ):
        if self.control_mode == 'entity_state':
            return self._move_to_position_entity_state(
                goal_handle,
                target,
                timeout_s,
                state,
                progress_start,
                progress_end,
            )
        if self.control_mode == 'trajectory':
            return self._move_to_position_trajectory(
                goal_handle,
                target,
                timeout_s,
                state,
                progress_start,
                progress_end,
            )

        feedback = CollectDish.Feedback()
        start_time = time.monotonic()
        start_position = self._get_joint_position()
        if start_position is None:
            return False

        travel = max(abs(target - start_position), 0.001)
        while rclpy.ok():
            if goal_handle.is_cancel_requested:
                self._safe_retract(goal_handle, feedback)
                goal_handle.canceled()
                return False

            position = self._get_joint_position()
            if position is None:
                return False

            error = target - position
            if abs(error) <= self.position_tolerance_m:
                self.command_publisher.publish(Float64(data=target))
                return True

            elapsed = time.monotonic() - start_time
            if elapsed > timeout_s:
                self.get_logger().warn(
                    f'{state} timed out at joint position {position:.3f} m.'
                )
                return False

            distance_done = min(abs(position - start_position) / travel, 1.0)
            progress = progress_start + (progress_end - progress_start) * distance_done
            self._publish_feedback(goal_handle, feedback, state, float(progress))
            self.command_publisher.publish(Float64(data=target))
            self._apply_effort(effort, self.effort_step_s)
            time.sleep(self.effort_step_s)

    def _move_to_position_trajectory(
        self,
        goal_handle,
        target,
        timeout_s,
        state,
        progress_start,
        progress_end,
    ):
        feedback = CollectDish.Feedback()
        move_s = min(self.trajectory_move_s, max(0.5, timeout_s))
        self._publish_joint_trajectory(target, move_s)
        start_time = time.monotonic()
        while rclpy.ok():
            if goal_handle.is_cancel_requested:
                self._publish_joint_trajectory(self.retracted_m, 1.0)
                goal_handle.canceled()
                return False
            elapsed = time.monotonic() - start_time
            fraction = min(elapsed / move_s, 1.0)
            progress = progress_start + (progress_end - progress_start) * fraction
            self._publish_feedback(goal_handle, feedback, state, float(progress))
            if elapsed >= move_s:
                self.command_publisher.publish(Float64(data=target))
                return True
            time.sleep(0.1)

    def _publish_joint_trajectory(self, target, move_s):
        msg = JointTrajectory()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.joint_names = [self.trajectory_joint_name]
        point = JointTrajectoryPoint()
        point.positions = [float(target)]
        point.velocities = [0.0]
        sec = int(move_s)
        nanosec = int((move_s - sec) * 1_000_000_000)
        point.time_from_start.sec = sec
        point.time_from_start.nanosec = nanosec
        msg.points = [point]
        self.trajectory_publisher.publish(msg)

    def _move_to_position_entity_state(
        self,
        goal_handle,
        target,
        timeout_s,
        state,
        progress_start,
        progress_end,
    ):
        feedback = CollectDish.Feedback()
        move_s = min(self.trajectory_move_s, max(0.5, timeout_s))
        start_time = time.monotonic()
        while rclpy.ok():
            if goal_handle.is_cancel_requested:
                self._set_pusher_entity_state(self.retracted_m, phase='retracting')
                if self.hide_pusher_when_idle:
                    self._hide_pusher_visual()
                goal_handle.canceled()
                return False
            elapsed = time.monotonic() - start_time
            fraction = min(elapsed / move_s, 1.0)
            current = self.retracted_m + (target - self.retracted_m) * fraction
            phase = 'extending'
            if target <= self.retracted_m + 1e-6:
                current = self.extension_m * (1.0 - fraction)
                phase = 'retracting'
            self._set_pusher_entity_state(current, fraction=fraction, phase=phase)
            progress = progress_start + (progress_end - progress_start) * fraction
            self._publish_feedback(goal_handle, feedback, state, float(progress))
            if elapsed >= move_s:
                self.command_publisher.publish(Float64(data=target))
                return True
            time.sleep(0.05)

    def _hold_entity_dump_pose(self, goal_handle, feedback):
        if self.control_mode != 'entity_state':
            self._apply_effort(self.hold_effort_n, self.hold_s)
            time.sleep(self.hold_s)
            return True
        start_time = time.monotonic()
        while rclpy.ok() and time.monotonic() - start_time < self.hold_s:
            if goal_handle.is_cancel_requested:
                goal_handle.canceled()
                return False
            dump_fraction = min((time.monotonic() - start_time) / max(self.hold_s, 0.1), 1.0)
            self._set_pusher_entity_state(
                self.retracted_m,
                fraction=dump_fraction,
                phase='dumping',
            )
            self._publish_feedback(goal_handle, feedback, 'dumping_food_waste', 0.95)
            time.sleep(0.05)
        return True

    def _animate_arm_segment(
        self,
        goal_handle,
        feedback,
        start_xyz,
        end_xyz,
        yaw,
        progress_start,
        progress_end,
        state,
        payload,
        duration_s=None,
    ):
        start_time = time.monotonic()
        move_s = duration_s if duration_s is not None else self.arm_segment_s
        while rclpy.ok():
            if goal_handle.is_cancel_requested:
                self._safe_retract_arm()
                goal_handle.canceled()
                return False
            elapsed = time.monotonic() - start_time
            fraction = min(elapsed / max(move_s, 0.05), 1.0)
            eased = self._smoothstep(fraction)
            xyz = self._lerp_xyz(start_xyz, end_xyz, eased)
            mode = 'closed' if payload in ('attached', 'plate_only') else 'open'
            self._set_arm_state(xyz, yaw, mode=mode)
            self._update_arm_payload(payload, xyz, yaw, pitch=0.0, fraction=eased)
            progress = progress_start + (progress_end - progress_start) * eased
            self._publish_feedback(goal_handle, feedback, state, float(progress))
            if fraction >= 1.0:
                return True
            time.sleep(self.arm_motion_step_s)
        return False

    def _animate_dump(self, goal_handle, feedback, arm_xyz, yaw):
        start_time = time.monotonic()
        while rclpy.ok():
            if goal_handle.is_cancel_requested:
                self._safe_retract_arm()
                goal_handle.canceled()
                return False
            elapsed = time.monotonic() - start_time
            fraction = min(elapsed / max(self.arm_dump_s, 0.1), 1.0)
            eased = self._smoothstep(fraction)
            pitch = -1.25 * eased
            plate_xyz = self._payload_xyz_from_arm(arm_xyz, yaw, pitch=pitch)
            self._set_arm_state(arm_xyz, yaw, mode='closed', pitch=pitch)
            self._set_plate_attached_state(plate_xyz, yaw, pitch=pitch)
            self._set_waste_visual_state(eased, start_xyz=self._waste_xyz_from_plate(plate_xyz))
            self._publish_feedback(
                goal_handle,
                feedback,
                'dumping_food_waste',
                0.66 + 0.12 * eased,
            )
            if fraction >= 1.0:
                return True
            time.sleep(self.arm_motion_step_s)
        return False

    def _update_arm_payload(self, payload, arm_xyz, yaw, pitch=0.0, fraction=0.0):
        if payload == 'table':
            self._set_plate_visual_state(0.0)
            self._set_waste_visual_state(0.0)
            return
        if payload == 'attached':
            plate_xyz = self._payload_xyz_from_arm(arm_xyz, yaw, pitch=pitch)
            self._set_plate_attached_state(plate_xyz, yaw, pitch=pitch)
            self._set_waste_attached_state(self._waste_xyz_from_plate(plate_xyz))
            return
        if payload == 'plate_only':
            self._set_plate_attached_state(
                self._payload_xyz_from_arm(arm_xyz, yaw, pitch=pitch),
                yaw,
                pitch=pitch,
            )
            return
        if payload == 'placed':
            self._set_plate_visual_state(1.0)

    def _set_arm_state(self, xyz, yaw, mode='open', pitch=0.0):
        self._set_arm_link_visuals(xyz, yaw)
        state = EntityState()
        state.name = self.pusher_visual_entity
        state.reference_frame = 'world'
        state.pose.position.x = xyz[0]
        state.pose.position.y = xyz[1]
        state.pose.position.z = xyz[2]
        gripper_spread_roll = 0.0 if mode == 'closed' else 0.08
        qx, qy, qz, qw = quaternion_from_rpy(gripper_spread_roll, pitch, yaw)
        state.pose.orientation.x = qx
        state.pose.orientation.y = qy
        state.pose.orientation.z = qz
        state.pose.orientation.w = qw
        request = SetEntityState.Request()
        request.state = state
        self.set_entity_state_client.call_async(request)

    def _set_arm_link_visuals(self, wrist_xyz, robot_yaw):
        if self.latest_robot_pose is None:
            return
        shoulder_xyz = self._arm_shoulder_xyz(robot_yaw)
        elbow_xyz = self._arm_elbow_xyz(shoulder_xyz, wrist_xyz, robot_yaw)
        self._set_arm_segment_state(self.arm_upper_visual_entity, shoulder_xyz, elbow_xyz)
        self._set_arm_segment_state(self.arm_forearm_visual_entity, elbow_xyz, wrist_xyz)

    def _set_arm_segment_state(self, entity_name, start_xyz, end_xyz):
        center = (
            (start_xyz[0] + end_xyz[0]) * 0.5,
            (start_xyz[1] + end_xyz[1]) * 0.5,
            (start_xyz[2] + end_xyz[2]) * 0.5,
        )
        direction = (
            end_xyz[0] - start_xyz[0],
            end_xyz[1] - start_xyz[1],
            end_xyz[2] - start_xyz[2],
        )
        yaw, pitch = self._yaw_pitch_from_vector(direction)
        state = EntityState()
        state.name = entity_name
        state.reference_frame = 'world'
        state.pose.position.x = center[0]
        state.pose.position.y = center[1]
        state.pose.position.z = center[2]
        qx, qy, qz, qw = quaternion_from_rpy(0.0, pitch, yaw)
        state.pose.orientation.x = qx
        state.pose.orientation.y = qy
        state.pose.orientation.z = qz
        state.pose.orientation.w = qw
        request = SetEntityState.Request()
        request.state = state
        self.set_entity_state_client.call_async(request)

    def _arm_shoulder_xyz(self, robot_yaw):
        return self._robot_relative_xyz(
            self.arm_shoulder_forward_m,
            self.arm_shoulder_lateral_m,
            self._world_z(self.arm_shoulder_z_m),
            robot_yaw,
        )

    def _arm_elbow_xyz(self, shoulder_xyz, wrist_xyz, robot_yaw):
        vector = (
            wrist_xyz[0] - shoulder_xyz[0],
            wrist_xyz[1] - shoulder_xyz[1],
            wrist_xyz[2] - shoulder_xyz[2],
        )
        distance = max(self._norm(vector), 0.001)
        upper = self.arm_upper_length_m
        forearm = self.arm_forearm_length_m
        reach = min(distance, max(upper + forearm - 0.01, 0.01))
        direction = self._scale(vector, 1.0 / distance)
        along = (upper * upper - forearm * forearm + reach * reach) / (2.0 * reach)
        along = max(min(along, upper), -upper)
        lift = math.sqrt(max(upper * upper - along * along, 0.0))
        up = (0.0, 0.0, 1.0)
        normal = self._sub(up, self._scale(direction, self._dot(up, direction)))
        normal_norm = self._norm(normal)
        if normal_norm < 0.001:
            normal = (-math.sin(robot_yaw), math.cos(robot_yaw), 0.0)
        else:
            normal = self._scale(normal, 1.0 / normal_norm)
        return self._add(
            shoulder_xyz,
            self._add(self._scale(direction, along), self._scale(normal, lift)),
        )

    def _safe_retract_arm(self):
        if self.latest_robot_pose is None or not self.set_entity_state_client.service_is_ready():
            return
        yaw = yaw_from_quaternion(self.latest_robot_pose.orientation)
        self._set_arm_state(
            self._robot_relative_xyz(
                self.arm_stowed_forward_m,
                0.0,
                self._world_z(self.arm_stowed_z_m),
                yaw,
            ),
            yaw,
            mode='open',
        )

    def _hide_arm_visuals(self):
        for entity_name, y_offset in (
            (self.pusher_visual_entity, 20.0),
            (self.arm_upper_visual_entity, 20.4),
            (self.arm_forearm_visual_entity, 20.8),
        ):
            state = EntityState()
            state.name = entity_name
            state.reference_frame = 'world'
            state.pose.position.x = 20.0
            state.pose.position.y = y_offset
            state.pose.position.z = 0.35
            state.pose.orientation.w = 1.0
            request = SetEntityState.Request()
            request.state = state
            self.set_entity_state_client.call_async(request)

    def _payload_xyz_from_arm(self, arm_xyz, yaw=None, pitch=0.0):
        forward_x = 0.0
        forward_y = 0.0
        vertical = -self.arm_payload_clearance_m
        if yaw is not None:
            local_x = (
                self.arm_payload_forward_offset_m * math.cos(pitch)
                - self.arm_payload_clearance_m * math.sin(pitch)
            )
            vertical = (
                -self.arm_payload_forward_offset_m * math.sin(pitch)
                - self.arm_payload_clearance_m * math.cos(pitch)
            )
            forward_x = local_x * math.cos(yaw)
            forward_y = local_x * math.sin(yaw)
        return (
            arm_xyz[0] + forward_x,
            arm_xyz[1] + forward_y,
            arm_xyz[2] + vertical,
        )

    def _wrist_xyz_for_payload(self, payload_xyz, yaw, wrist_z):
        return (
            payload_xyz[0] - self.arm_payload_forward_offset_m * math.cos(yaw),
            payload_xyz[1] - self.arm_payload_forward_offset_m * math.sin(yaw),
            wrist_z,
        )

    @staticmethod
    def _waste_xyz_from_plate(plate_xyz):
        return (plate_xyz[0], plate_xyz[1], plate_xyz[2] + 0.085)

    def _robot_relative_xyz(self, forward, lateral, z_or_world_z, yaw):
        return (
            self.latest_robot_pose.position.x
            + forward * math.cos(yaw)
            - lateral * math.sin(yaw),
            self.latest_robot_pose.position.y
            + forward * math.sin(yaw)
            + lateral * math.cos(yaw),
            z_or_world_z,
        )

    def _world_z(self, robot_relative_z):
        if self.latest_robot_pose is None:
            return robot_relative_z
        return self.latest_robot_pose.position.z + robot_relative_z

    def _safe_payload_world_z(self, robot_relative_z):
        return self._world_z(robot_relative_z)

    @staticmethod
    def _lerp_xyz(start_xyz, end_xyz, fraction):
        return (
            start_xyz[0] + (end_xyz[0] - start_xyz[0]) * fraction,
            start_xyz[1] + (end_xyz[1] - start_xyz[1]) * fraction,
            start_xyz[2] + (end_xyz[2] - start_xyz[2]) * fraction,
        )

    @staticmethod
    def _smoothstep(fraction):
        fraction = min(max(fraction, 0.0), 1.0)
        return fraction * fraction * (3.0 - 2.0 * fraction)

    @staticmethod
    def _yaw_pitch_from_vector(vector):
        horizontal = math.hypot(vector[0], vector[1])
        if horizontal < 0.001:
            yaw = 0.0
        else:
            yaw = math.atan2(vector[1], vector[0])
        pitch = math.atan2(-vector[2], max(horizontal, 0.001))
        return yaw, pitch

    @staticmethod
    def _norm(vector):
        return math.sqrt(vector[0] * vector[0] + vector[1] * vector[1] + vector[2] * vector[2])

    @staticmethod
    def _dot(a, b):
        return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]

    @staticmethod
    def _add(a, b):
        return (a[0] + b[0], a[1] + b[1], a[2] + b[2])

    @staticmethod
    def _sub(a, b):
        return (a[0] - b[0], a[1] - b[1], a[2] - b[2])

    @staticmethod
    def _scale(vector, scalar):
        return (vector[0] * scalar, vector[1] * scalar, vector[2] * scalar)

    def _set_pusher_entity_state(self, extension, fraction=0.0, phase='extending'):
        extension = max(self.retracted_m, min(self.extension_m, float(extension)))
        if self.latest_robot_pose is None:
            return
        robot_pose = self.latest_robot_pose
        yaw = yaw_from_quaternion(robot_pose.orientation)
        collect_fraction = min(max(fraction, 0.0), 1.0)
        travel = max(self.extension_m - self.retracted_m, 1e-6)
        approach_fraction = min(max((extension - self.retracted_m) / travel, 0.0), 1.0)
        if phase == 'extending':
            tilt_fraction = 0.0
        elif phase == 'dumping':
            tilt_fraction = collect_fraction
        else:
            tilt_fraction = 0.0
        start_forward = self.gripper_retracted_forward_m
        start_x = robot_pose.position.x + start_forward * math.cos(yaw)
        start_y = robot_pose.position.y + start_forward * math.sin(yaw)
        target_x, target_y = self._gripper_target_xy(robot_pose, yaw)
        x = start_x + (target_x - start_x) * approach_fraction
        y = start_y + (target_y - start_y) * approach_fraction
        z = robot_pose.position.z + 0.43 + 0.12 * tilt_fraction
        state = EntityState()
        state.name = self.pusher_visual_entity
        state.reference_frame = 'world'
        state.pose.position.x = x
        state.pose.position.y = y
        state.pose.position.z = z
        tilt = -1.05 * tilt_fraction
        qx, qy, qz, qw = quaternion_from_rpy(0.0, tilt, yaw)
        state.pose.orientation.x = qx
        state.pose.orientation.y = qy
        state.pose.orientation.z = qz
        state.pose.orientation.w = qw
        request = SetEntityState.Request()
        request.state = state
        self.set_entity_state_client.call_async(request)
        attached_xyz = self._attached_payload_xyz(x, y, z, yaw)
        if phase == 'extending':
            self._set_plate_visual_state(0.0)
            self._set_waste_visual_state(0.0)
        elif phase == 'retracting':
            self._set_plate_attached_state(attached_xyz, yaw)
            self._set_waste_attached_state(attached_xyz)
        elif phase == 'dumping':
            self._set_plate_visual_state(collect_fraction, start_xyz=attached_xyz)
            self._set_waste_visual_state(collect_fraction, start_xyz=attached_xyz)

    def _update_idle_gripper_visual(self):
        if self.control_mode != 'entity_state':
            return
        if self.active_table_id:
            return
        if self.hide_pusher_when_idle:
            return
        if not self.set_entity_state_client.service_is_ready():
            return
        if self.latest_robot_pose is None:
            return
        yaw = yaw_from_quaternion(self.latest_robot_pose.orientation)
        self._set_arm_state(
            self._robot_relative_xyz(self.arm_stowed_forward_m, 0.0, self._world_z(self.arm_stowed_z_m), yaw),
            yaw,
            mode='open',
        )

    def _attached_payload_xyz(self, gripper_x, gripper_y, gripper_z, yaw):
        tray_forward = self.gripper_tray_forward_m + 0.02
        return (
            gripper_x + tray_forward * math.cos(yaw),
            gripper_y + tray_forward * math.sin(yaw),
            gripper_z - 0.065,
        )

    def _set_plate_attached_state(self, attached_xyz, yaw, pitch=0.0):
        if not self.active_table_id:
            return
        plate_name = f'{self.plate_entity_prefix}{self.active_table_id}'
        state = EntityState()
        state.name = plate_name
        state.reference_frame = 'world'
        state.pose.position.x = attached_xyz[0]
        state.pose.position.y = attached_xyz[1]
        state.pose.position.z = attached_xyz[2]
        qx, qy, qz, qw = quaternion_from_rpy(0.0, pitch, yaw)
        state.pose.orientation.x = qx
        state.pose.orientation.y = qy
        state.pose.orientation.z = qz
        state.pose.orientation.w = qw
        request = SetEntityState.Request()
        request.state = state
        self.set_entity_state_client.call_async(request)

    def _set_waste_attached_state(self, attached_xyz):
        if not self.active_table_id:
            return
        waste_name = f'{self.waste_entity_prefix}{self.active_table_id}'
        state = EntityState()
        state.name = waste_name
        state.reference_frame = 'world'
        state.pose.position.x = attached_xyz[0]
        state.pose.position.y = attached_xyz[1]
        state.pose.position.z = attached_xyz[2] + 0.015
        state.pose.orientation.w = 1.0
        request = SetEntityState.Request()
        request.state = state
        self.set_entity_state_client.call_async(request)

    def _set_plate_visual_state(self, fraction, start_xyz=None):
        if not self.active_table_id or self.latest_robot_pose is None:
            return
        plate_name = f'{self.plate_entity_prefix}{self.active_table_id}'
        robot_pose = self.latest_robot_pose
        yaw = yaw_from_quaternion(robot_pose.orientation)
        end_forward = self.storage_plate_x
        fraction = min(max(fraction, 0.0), 1.0)
        if start_xyz is not None:
            start_x, start_y, start_z = start_xyz
        elif self.collection_start_plate_pose is not None:
            start_x = self.collection_start_plate_pose.position.x
            start_y = self.collection_start_plate_pose.position.y
            start_z = self.collection_start_plate_pose.position.z
        else:
            start_x, start_y = self._plate_target_xy(robot_pose, yaw)
            start_z = robot_pose.position.z + 0.43
        end_x = (
            robot_pose.position.x
            + end_forward * math.cos(yaw)
            - self.storage_plate_y * math.sin(yaw)
        )
        end_y = (
            robot_pose.position.y
            + end_forward * math.sin(yaw)
            + self.storage_plate_y * math.cos(yaw)
        )
        world_x = start_x + (end_x - start_x) * fraction
        world_y = start_y + (end_y - start_y) * fraction
        state = EntityState()
        state.name = plate_name
        state.reference_frame = 'world'
        state.pose.position.x = world_x
        state.pose.position.y = world_y
        end_z = robot_pose.position.z + self.storage_plate_z
        state.pose.position.z = start_z + (end_z - start_z) * fraction
        qx, qy, qz, qw = quaternion_from_yaw(yaw)
        state.pose.orientation.x = qx
        state.pose.orientation.y = qy
        state.pose.orientation.z = qz
        state.pose.orientation.w = qw
        request = SetEntityState.Request()
        request.state = state
        self.set_entity_state_client.call_async(request)

    def _set_waste_visual_state(self, fraction, start_xyz=None):
        if not self.active_table_id or self.latest_robot_pose is None:
            return
        waste_name = f'{self.waste_entity_prefix}{self.active_table_id}'
        robot_pose = self.latest_robot_pose
        yaw = yaw_from_quaternion(robot_pose.orientation)
        end_forward = self.waste_bin_x
        fraction = min(max(fraction, 0.0), 1.0)
        pour_fraction = min(max((fraction - 0.18) / 0.55, 0.0), 1.0)
        if start_xyz is not None:
            start_x, start_y, start_z = start_xyz[0], start_xyz[1], start_xyz[2] + 0.035
        elif self.collection_start_waste_pose is not None:
            start_x = self.collection_start_waste_pose.position.x
            start_y = self.collection_start_waste_pose.position.y
            start_z = self.collection_start_waste_pose.position.z
        else:
            start_x, start_y = self._plate_target_xy(robot_pose, yaw)
            start_z = robot_pose.position.z + 0.44
        end_x = (
            robot_pose.position.x
            + end_forward * math.cos(yaw)
            - self.waste_bin_y * math.sin(yaw)
        )
        end_y = (
            robot_pose.position.y
            + end_forward * math.sin(yaw)
            + self.waste_bin_y * math.cos(yaw)
        )
        world_x = start_x + (end_x - start_x) * pour_fraction
        world_y = start_y + (end_y - start_y) * pour_fraction
        end_z = robot_pose.position.z + self.waste_bin_z
        z = start_z + (end_z - start_z) * pour_fraction
        state = EntityState()
        state.name = waste_name
        state.reference_frame = 'world'
        state.pose.position.x = world_x
        state.pose.position.y = world_y
        state.pose.position.z = z
        state.pose.orientation.w = 1.0
        request = SetEntityState.Request()
        request.state = state
        self.set_entity_state_client.call_async(request)

    def _entity_pose(self, entity_name):
        return self.model_poses.get(entity_name)

    def _plate_target_xy(self, robot_pose, yaw):
        if self.collection_start_plate_pose is not None:
            return (
                self.collection_start_plate_pose.position.x,
                self.collection_start_plate_pose.position.y,
            )
        forward = (
            self.gripper_retracted_forward_m
            + self.extension_m
            + self.gripper_tray_forward_m
        )
        return (
            robot_pose.position.x
            + forward * math.cos(yaw)
            - self.gripper_target_lateral_offset_m * math.sin(yaw),
            robot_pose.position.y
            + forward * math.sin(yaw)
            + self.gripper_target_lateral_offset_m * math.cos(yaw),
        )

    def _gripper_target_xy(self, robot_pose, yaw):
        plate_x, plate_y = self._plate_target_xy(robot_pose, yaw)
        origin_forward_offset = (
            self.gripper_tray_forward_m
            - self.gripper_target_forward_offset_m
        )
        origin_lateral_offset = self.gripper_target_lateral_offset_m
        return (
            plate_x
            - origin_forward_offset * math.cos(yaw)
            + origin_lateral_offset * math.sin(yaw),
            plate_y
            - origin_forward_offset * math.sin(yaw)
            - origin_lateral_offset * math.cos(yaw),
        )

    def _hide_pusher_visual(self):
        self._hide_arm_visuals()

    def _safe_retract(self, goal_handle, feedback):
        self._publish_feedback(goal_handle, feedback, 'safe_retract', 0.0)
        deadline = time.monotonic() + min(self.retract_timeout_s, 4.0)
        while rclpy.ok() and time.monotonic() < deadline:
            position = self._get_joint_position()
            if position is not None and position <= self.retracted_m + self.position_tolerance_m:
                return
            self._apply_effort(self.retraction_effort_n, self.effort_step_s)
            time.sleep(self.effort_step_s)

    def _get_joint_position(self, log_failure=True):
        request = GetJointProperties.Request()
        request.joint_name = self.joint_name
        future = self.get_joint_client.call_async(request)
        self._wait_future(future, timeout_s=1.0)
        if not future.done() or future.result() is None:
            if log_failure:
                self.get_logger().warn('Timed out reading front pusher joint.')
            return None
        response = future.result()
        if not response.success or not response.position:
            if log_failure:
                self.get_logger().warn(
                    f'Failed to read joint {self.joint_name}: {response.status_message}'
                )
            return None
        return float(response.position[0])

    def _apply_effort(self, effort, duration_s):
        request = ApplyJointEffort.Request()
        request.joint_name = self.joint_name
        request.effort = float(effort)
        request.start_time = Time(sec=0, nanosec=0)
        sec = int(duration_s)
        nanosec = int((duration_s - sec) * 1_000_000_000)
        request.duration = Duration(sec=sec, nanosec=nanosec)
        future = self.apply_effort_client.call_async(request)
        self._wait_future(future, timeout_s=1.0)
        if not future.done() or future.result() is None:
            self.get_logger().warn('Timed out applying pusher effort.')
            return False
        if not future.result().success:
            self.get_logger().warn(f'ApplyJointEffort failed: {future.result().status_message}')
            return False
        return True

    @staticmethod
    def _wait_future(future, timeout_s):
        deadline = time.monotonic() + timeout_s
        while rclpy.ok() and not future.done() and time.monotonic() < deadline:
            time.sleep(0.01)

    @staticmethod
    def _publish_feedback(goal_handle, feedback, state, progress):
        feedback.state = state
        feedback.progress = max(0.0, min(1.0, progress))
        goal_handle.publish_feedback(feedback)


def main(args=None):
    rclpy.init(args=args)
    node = PusherControllerNode()
    executor = MultiThreadedExecutor()
    executor.add_node(node)
    try:
        executor.spin()
    finally:
        node.destroy_node()
        rclpy.shutdown()
