import sys
import time

import rclpy
from dishbot_msgs.action import CollectDish
from gazebo_msgs.srv import GetEntityState
from geometry_msgs.msg import PoseStamped
from rclpy.action import ActionClient
from rclpy.node import Node


class CollectDishTest(Node):
    def __init__(self):
        super().__init__('collect_dish_test')
        self.declare_parameter('table_id', 'table_1')
        self.declare_parameter('timeout_s', 25.0)
        self.declare_parameter('check_plate_in_storage', True)
        self.declare_parameter('robot_entity', 'dishbot')
        self.client = ActionClient(self, CollectDish, '/collect_dish')
        self.entity_state_client = self.create_client(GetEntityState, '/get_entity_state')
        self.result = None

    def run(self):
        table_id = self.get_parameter('table_id').value
        timeout_s = float(self.get_parameter('timeout_s').value)
        self.get_logger().info(f'Waiting for /collect_dish action server for {timeout_s:.1f}s.')
        if not self.client.wait_for_server(timeout_sec=timeout_s):
            self.get_logger().error('/collect_dish action server is unavailable.')
            return 1

        goal = CollectDish.Goal()
        goal.table_id = table_id
        goal.plate_pose = PoseStamped()
        goal.plate_pose.header.frame_id = 'map'
        goal.plate_pose.header.stamp = self.get_clock().now().to_msg()

        send_future = self.client.send_goal_async(
            goal,
            feedback_callback=self._feedback_callback,
        )
        self._wait_future(send_future, timeout_s=5.0)
        if not send_future.done() or send_future.result() is None:
            self.get_logger().error('Timed out sending CollectDish goal.')
            return 1
        goal_handle = send_future.result()
        if not goal_handle.accepted:
            self.get_logger().error('CollectDish goal was rejected.')
            return 1

        result_future = goal_handle.get_result_async()
        self._wait_future(result_future, timeout_s=timeout_s)
        if not result_future.done() or result_future.result() is None:
            self.get_logger().error('Timed out waiting for CollectDish result.')
            return 1

        wrapped_result = result_future.result()
        result = wrapped_result.result
        if result.success:
            self.get_logger().info(f'CollectDish succeeded: {result.message}')
            if self.get_parameter('check_plate_in_storage').value:
                if not self._plate_is_in_storage(table_id):
                    self.get_logger().error(
                        'CollectDish action succeeded, but plate was not detected in storage bay.'
                    )
                    return 1
            return 0
        self.get_logger().error(f'CollectDish failed: {result.message}')
        return 1

    def _feedback_callback(self, feedback_msg):
        feedback = feedback_msg.feedback
        self.get_logger().info(
            f'CollectDish feedback: state={feedback.state}, progress={feedback.progress:.2f}'
        )

    def _wait_future(self, future, timeout_s):
        deadline = time.monotonic() + timeout_s
        while rclpy.ok() and not future.done() and time.monotonic() < deadline:
            rclpy.spin_once(self, timeout_sec=0.05)

    def _plate_is_in_storage(self, table_id):
        if not self.entity_state_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().warn(
                '/get_entity_state is unavailable; skipping plate storage verification.'
            )
            return True

        request = GetEntityState.Request()
        request.name = f'plate_{table_id}'
        request.reference_frame = self.get_parameter('robot_entity').value
        future = self.entity_state_client.call_async(request)
        self._wait_future(future, timeout_s=2.0)
        if not future.done() or future.result() is None:
            self.get_logger().warn('Timed out reading plate entity state; skipping verification.')
            return True
        response = future.result()
        if not response.success:
            self.get_logger().warn(f'Could not read {request.name} state; skipping verification.')
            return True

        p = response.state.pose.position
        in_storage = -0.42 <= p.x <= 0.18 and abs(p.y) <= 0.25 and 0.55 <= p.z <= 0.78
        self.get_logger().info(
            f'{request.name} relative to {request.reference_frame}: '
            f'x={p.x:.3f}, y={p.y:.3f}, z={p.z:.3f}, in_storage={in_storage}'
        )
        return in_storage


def main(args=None):
    rclpy.init(args=args)
    node = CollectDishTest()
    try:
        exit_code = node.run()
    finally:
        node.destroy_node()
        rclpy.shutdown()
    sys.exit(exit_code)
