import math
import time

import rclpy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data


def yaw_from_quaternion(q):
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


class DriveTest(Node):
    def __init__(self):
        super().__init__('drive_test')
        self.declare_parameter('forward_speed_mps', 0.2)
        self.declare_parameter('fast_forward_speed_mps', 0.5)
        self.declare_parameter('turn_speed_rps', 0.5)
        self.declare_parameter('forward_duration_s', 3.0)
        self.declare_parameter('fast_forward_duration_s', 2.0)
        self.declare_parameter('turn_duration_s', 3.0)
        self.declare_parameter('stop_duration_s', 1.5)
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.latest_odom = None
        self.create_subscription(
            Odometry,
            '/odom',
            self._odom_callback,
            qos_profile_sensor_data,
        )

    def _odom_callback(self, msg):
        self.latest_odom = msg

    def run(self):
        self.get_logger().info('Starting drive stability command sequence.')
        self._wait_for_odom()
        start_pose = self._current_pose()
        self._log_pose('start_pose', start_pose)
        self._send_for(
            linear_x=float(self.get_parameter('forward_speed_mps').value),
            angular_z=0.0,
            duration_s=float(self.get_parameter('forward_duration_s').value),
            label='forward_0_2_mps',
        )
        self._stop('stop_after_forward')
        self._send_for(
            linear_x=float(self.get_parameter('fast_forward_speed_mps').value),
            angular_z=0.0,
            duration_s=float(self.get_parameter('fast_forward_duration_s').value),
            label='forward_0_5_mps',
        )
        self._stop('stop_after_fast_forward')
        self._send_for(
            linear_x=0.0,
            angular_z=float(self.get_parameter('turn_speed_rps').value),
            duration_s=float(self.get_parameter('turn_duration_s').value),
            label='turn_0_5_rps',
        )
        self._stop('final_stop')
        end_pose = self._current_pose()
        self._log_pose('end_pose', end_pose)
        if start_pose is not None and end_pose is not None:
            distance = math.hypot(end_pose[0] - start_pose[0], end_pose[1] - start_pose[1])
            yaw_delta = math.atan2(
                math.sin(end_pose[2] - start_pose[2]),
                math.cos(end_pose[2] - start_pose[2]),
            )
            self.get_logger().info(
                f'odom delta: distance={distance:.3f} m, yaw_delta={yaw_delta:.3f} rad'
            )
        self.get_logger().info('Drive stability command sequence complete.')

    def _wait_for_odom(self):
        deadline = time.monotonic() + 3.0
        while rclpy.ok() and self.latest_odom is None and time.monotonic() < deadline:
            rclpy.spin_once(self, timeout_sec=0.1)
        if self.latest_odom is None:
            self.get_logger().warn('No /odom received before drive sequence.')

    def _current_pose(self):
        if self.latest_odom is None:
            return None
        pose = self.latest_odom.pose.pose
        return (
            pose.position.x,
            pose.position.y,
            yaw_from_quaternion(pose.orientation),
        )

    def _log_pose(self, label, pose):
        if pose is None:
            self.get_logger().warn(f'{label}: unavailable')
            return
        self.get_logger().info(
            f'{label}: x={pose[0]:.3f}, y={pose[1]:.3f}, yaw={pose[2]:.3f}'
        )

    def _send_for(self, linear_x, angular_z, duration_s, label):
        msg = Twist()
        msg.linear.x = linear_x
        msg.angular.z = angular_z
        end_time = time.monotonic() + duration_s
        self.get_logger().info(
            f'{label}: cmd_vel linear.x={linear_x:.3f}, angular.z={angular_z:.3f}, '
            f'duration={duration_s:.1f}s'
        )
        while rclpy.ok() and time.monotonic() < end_time:
            self.cmd_pub.publish(msg)
            rclpy.spin_once(self, timeout_sec=0.02)
            time.sleep(0.08)

    def _stop(self, label):
        stop_duration_s = float(self.get_parameter('stop_duration_s').value)
        msg = Twist()
        end_time = time.monotonic() + stop_duration_s
        self.get_logger().info(f'{label}: publishing zero cmd_vel for {stop_duration_s:.1f}s')
        while rclpy.ok() and time.monotonic() < end_time:
            self.cmd_pub.publish(msg)
            rclpy.spin_once(self, timeout_sec=0.02)
            time.sleep(0.08)
        if self.latest_odom is not None:
            twist = self.latest_odom.twist.twist
            linear_speed = math.hypot(twist.linear.x, twist.linear.y)
            angular_speed = abs(twist.angular.z)
            self.get_logger().info(
                f'{label}: odom speed after stop linear={linear_speed:.4f} m/s, '
                f'angular={angular_speed:.4f} rad/s'
            )


def main(args=None):
    rclpy.init(args=args)
    node = DriveTest()
    try:
        node.run()
    finally:
        node.destroy_node()
        rclpy.shutdown()
