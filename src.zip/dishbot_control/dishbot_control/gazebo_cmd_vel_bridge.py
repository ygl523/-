import math

import rclpy
from gazebo_msgs.msg import EntityState
from gazebo_msgs.srv import GetEntityState, SetEntityState
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data


def yaw_from_quaternion(q):
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


def quaternion_from_yaw(yaw):
    half = yaw * 0.5
    return (0.0, 0.0, math.sin(half), math.cos(half))


class GazeboCmdVelBridge(Node):
    """Fallback Gazebo base controller for early demo visibility.

    It integrates /cmd_vel and updates the dishbot model pose through
    /set_entity_state. This is intentionally simple and is used only
    until the Gazebo diff drive plugin topic wiring is fully validated.
    """

    def __init__(self):
        super().__init__('gazebo_cmd_vel_bridge')
        self.callback_group = ReentrantCallbackGroup()
        self.declare_parameter('enabled', True)
        self.declare_parameter('model_name', 'dishbot')
        self.declare_parameter('base_z', 0.095)
        self.declare_parameter('update_rate_hz', 30.0)
        self.declare_parameter('cmd_timeout_s', 0.35)
        self.declare_parameter('max_linear_mps', 0.55)
        self.declare_parameter('max_angular_rps', 0.8)

        self.enabled = bool(self.get_parameter('enabled').value)
        self.model_name = self.get_parameter('model_name').value
        self.base_z = float(self.get_parameter('base_z').value)
        self.cmd_timeout_s = float(self.get_parameter('cmd_timeout_s').value)
        self.max_linear_mps = float(self.get_parameter('max_linear_mps').value)
        self.max_angular_rps = float(self.get_parameter('max_angular_rps').value)

        self.x = -4.10
        self.y = 2.25
        self.yaw = 0.0
        self.cmd = Twist()
        self.last_cmd_time = self.get_clock().now()
        self.last_update_time = self.get_clock().now()
        self.service_ready_logged = False
        self.entity_ready = False
        self.entity_wait_logged = False
        self.pending_entity_request = False

        self.set_entity_state_client = self.create_client(
            SetEntityState,
            '/set_entity_state',
            callback_group=self.callback_group,
        )
        self.get_entity_state_client = self.create_client(
            GetEntityState,
            '/get_entity_state',
            callback_group=self.callback_group,
        )
        self.create_subscription(Twist, '/cmd_vel', self._cmd_callback, 10)
        self.create_subscription(
            Odometry,
            '/odom',
            self._odom_callback,
            qos_profile_sensor_data,
        )
        period = 1.0 / float(self.get_parameter('update_rate_hz').value)
        self.create_timer(period, self._update, callback_group=self.callback_group)
        if self.enabled:
            self.get_logger().warn(
                'Fallback Gazebo cmd_vel bridge is enabled. '
                'It moves the model through /set_entity_state.'
            )

    def _cmd_callback(self, msg):
        self.cmd = msg
        self.last_cmd_time = self.get_clock().now()
        if abs(msg.linear.x) < 1e-4 and abs(msg.angular.z) < 1e-4:
            self._send_state(linear=0.0, angular=0.0)

    def _odom_callback(self, msg):
        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y
        self.yaw = yaw_from_quaternion(msg.pose.pose.orientation)

    def _update(self):
        if not self.enabled:
            return
        if (
            not self.set_entity_state_client.service_is_ready()
            or not self.get_entity_state_client.service_is_ready()
        ):
            self.set_entity_state_client.wait_for_service(timeout_sec=0.01)
            self.get_entity_state_client.wait_for_service(timeout_sec=0.01)
            return
        if not self.service_ready_logged:
            self.get_logger().info('/set_entity_state and /get_entity_state services are ready.')
            self.service_ready_logged = True

        now = self.get_clock().now()
        dt = (now - self.last_update_time).nanoseconds * 1e-9
        self.last_update_time = now
        if dt <= 0.0 or dt > 0.2:
            return

        if not self.entity_ready:
            self._request_entity_state_once()
            return

        cmd_age = (now - self.last_cmd_time).nanoseconds * 1e-9
        if cmd_age > self.cmd_timeout_s:
            return
        else:
            linear = max(-self.max_linear_mps, min(self.max_linear_mps, self.cmd.linear.x))
            angular = max(-self.max_angular_rps, min(self.max_angular_rps, self.cmd.angular.z))

        if abs(linear) < 1e-4 and abs(angular) < 1e-4:
            return

        self.yaw += angular * dt
        self.x += linear * math.cos(self.yaw) * dt
        self.y += linear * math.sin(self.yaw) * dt

        self._send_state(linear=linear, angular=angular)

    def _send_state(self, linear=0.0, angular=0.0):
        if not self.entity_ready or not self.set_entity_state_client.service_is_ready():
            return
        qx, qy, qz, qw = quaternion_from_yaw(self.yaw)
        state = EntityState()
        state.name = self.model_name
        state.pose.position.x = self.x
        state.pose.position.y = self.y
        state.pose.position.z = self.base_z
        state.pose.orientation.x = qx
        state.pose.orientation.y = qy
        state.pose.orientation.z = qz
        state.pose.orientation.w = qw
        state.twist.linear.x = linear
        state.twist.angular.z = angular
        state.reference_frame = 'world'

        request = SetEntityState.Request()
        request.state = state
        self.set_entity_state_client.call_async(request)

    def _request_entity_state_once(self):
        if self.pending_entity_request:
            return
        request = GetEntityState.Request()
        request.name = self.model_name
        request.reference_frame = 'world'
        future = self.get_entity_state_client.call_async(request)
        self.pending_entity_request = True
        future.add_done_callback(self._entity_state_callback)

    def _entity_state_callback(self, future):
        self.pending_entity_request = False
        try:
            response = future.result()
        except Exception as exc:  # noqa: BLE001
            if not self.entity_wait_logged:
                self.get_logger().warn(f'Waiting for Gazebo entity {self.model_name}: {exc}')
                self.entity_wait_logged = True
            return
        if response is None or not response.success:
            if not self.entity_wait_logged:
                self.get_logger().warn(f'Waiting for Gazebo entity {self.model_name} to spawn.')
                self.entity_wait_logged = True
            return

        pose = response.state.pose
        self.x = pose.position.x
        self.y = pose.position.y
        self.base_z = pose.position.z
        self.yaw = yaw_from_quaternion(pose.orientation)
        self.entity_ready = True
        self.get_logger().info(
            f'Gazebo entity {self.model_name} is ready at '
            f'x={self.x:.3f}, y={self.y:.3f}, z={self.base_z:.3f}.'
        )


def main(args=None):
    rclpy.init(args=args)
    node = GazeboCmdVelBridge()
    executor = MultiThreadedExecutor()
    executor.add_node(node)
    try:
        executor.spin()
    finally:
        node.destroy_node()
        rclpy.shutdown()
