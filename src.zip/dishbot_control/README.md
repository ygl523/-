# dishbot_control

Control package for the Dishbot base and plate-handling arm.

## Current Implementation

- Base driving is handled by the Gazebo diff drive plugin configured in `dishbot_description`.
- `gazebo_cmd_vel_bridge` is enabled as an early-stage fallback. It subscribes to `/cmd_vel` and moves the Gazebo `dishbot` model through `/gazebo/set_model_state` so the demo remains visible while the diff drive plugin wiring is being validated.
- `drive_test` publishes `/cmd_vel` commands for forward, stop, fast-forward, stop, rotate, and final stop checks.
- `pusher_controller_node` provides `/collect_dish` using `dishbot_msgs/action/CollectDish`.
- In the default `entity_state` mode, `/collect_dish` runs a visible arm sequence:
  reach above the plate, descend to grasp, lift, move to the waste bin, tilt to dump food waste,
  place the empty plate on the upper storage rack, and return home.
- The arm sequence uses Gazebo Classic `/set_entity_state` to keep the plate and food waste aligned
  with the visible gripper and to avoid obvious visual interpenetration during the demo.

This keeps the stage 4 loop small while leaving room to swap in `ros2_control` later.

To disable the fallback bridge after the diff drive plugin is confirmed working:

```bash
ros2 launch dishbot_control control.launch.py --ros-args -p gazebo_cmd_vel_bridge.enabled:=false
```

## Run Control Node

```bash
cd /home/ygl/zidong
colcon build
source install/setup.bash
ros2 launch dishbot_control control.launch.py
```

`dishbot_gazebo restaurant_sim.launch.py` starts this node by default. If you launched Gazebo with `start_control:=false`, run it manually:

```bash
ros2 launch dishbot_gazebo restaurant_sim.launch.py
ros2 launch dishbot_control control.launch.py
```

## Drive Test

```bash
ros2 run dishbot_control drive_test --ros-args --params-file src/dishbot_control/config/control.yaml
```

The expected sequence is:

1. Drive forward at `0.2 m/s`.
2. Stop.
3. Drive forward at `0.5 m/s`.
4. Stop.
5. Rotate at `0.5 rad/s`.
6. Stop.

## Collect Dish Test

Start Gazebo and the arm controller first, then run:

```bash
ros2 run dishbot_control collect_dish_test --ros-args -p table_id:=table_1
```

If Gazebo exposes `/get_entity_state`, the test also checks that `plate_table_1` ends up inside the robot storage bay relative to the `dishbot` entity.

Or use the action CLI:

```bash
ros2 action send_goal /collect_dish dishbot_msgs/action/CollectDish "{table_id: 'table_1'}"
```

## Notes

- `require_pose_check` is currently `false` in `config/control.yaml` because navigation and precise table alignment are implemented in later stages.
- The current arm is a deterministic Gazebo visual/kinematic sequence, not a full inverse-kinematics or collision-planned manipulator.
- If the arm does not move, verify Gazebo is running and exposes `/set_entity_state`.
