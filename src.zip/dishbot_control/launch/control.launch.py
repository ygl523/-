from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    use_sim_time = LaunchConfiguration('use_sim_time')
    use_cmd_vel_bridge = LaunchConfiguration('use_cmd_vel_bridge')
    config_file = PathJoinSubstitution([
        FindPackageShare('dishbot_control'),
        'config',
        'control.yaml',
    ])

    return LaunchDescription([
        DeclareLaunchArgument(
            'use_sim_time',
            default_value='true',
            description='Use Gazebo simulation clock.',
        ),
        DeclareLaunchArgument(
            'use_cmd_vel_bridge',
            default_value='true',
            description='Start fallback /cmd_vel to /set_entity_state bridge.',
        ),
        Node(
            package='dishbot_control',
            executable='pusher_controller_node',
            name='pusher_controller_node',
            output='screen',
            parameters=[
                config_file,
                {'use_sim_time': use_sim_time},
            ],
        ),
        Node(
            package='dishbot_control',
            executable='gazebo_cmd_vel_bridge',
            name='gazebo_cmd_vel_bridge',
            output='screen',
            condition=IfCondition(use_cmd_vel_bridge),
            parameters=[
                config_file,
                {'use_sim_time': use_sim_time},
            ],
        ),
    ])
