from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    gui = LaunchConfiguration('gui')
    start_task_manager = LaunchConfiguration('start_task_manager')

    restaurant_sim_launch = PathJoinSubstitution([
        FindPackageShare('dishbot_gazebo'),
        'launch',
        'restaurant_sim.launch.py',
    ])
    task_manager_launch = PathJoinSubstitution([
        FindPackageShare('dishbot_task_manager'),
        'launch',
        'task_manager.launch.py',
    ])

    return LaunchDescription([
        DeclareLaunchArgument(
            'gui',
            default_value='true',
            description='Start Gazebo GUI.',
        ),
        DeclareLaunchArgument(
            'start_task_manager',
            default_value='true',
            description='Start /go_to_table and /cycle_collect action servers.',
        ),
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(restaurant_sim_launch),
            launch_arguments={
                'gui': gui,
                'start_control': 'true',
                'use_cmd_vel_bridge': 'true',
                'enable_diff_drive': 'false',
            }.items(),
        ),
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(task_manager_launch),
            condition=IfCondition(start_task_manager),
            launch_arguments={
                'return_after_single_table': 'true',
            }.items(),
        ),
    ])
