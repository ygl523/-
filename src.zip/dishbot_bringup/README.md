# dishbot_bringup

Top-level demo launch files for running the complete restaurant collection simulation.

Stage 1 contains the package scaffold. The final demo entry point will be `full_restaurant_demo.launch.py`.
