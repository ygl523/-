# dishbot_task_manager

Action-based task orchestration for designated-table and cycle collection.

## Current Stage

The package now includes a minimal `table_1` demo node before full Nav2 integration.

It performs:

1. Read `restaurant_waypoints.yaml`.
2. Move the robot to `table_1.approach_pose` using `/cmd_vel`.
3. Move to `table_1.collect_pose`.
4. Stop and call `/collect_dish`.
5. Return to `dishwashing_room.return_pose`.

This is a staged demo controller. Full `GoToTable` / `CycleCollect` action servers and Nav2 integration are still TODO.

## Run

Start Gazebo first:

```bash
cd /home/ygl/zidong
source install/setup.bash
ros2 launch dishbot_gazebo restaurant_sim.launch.py
```

Then run the minimal table demo:

```bash
ros2 launch dishbot_task_manager table1_demo.launch.py
```

Or directly:

```bash
ros2 run dishbot_task_manager table1_demo
```
