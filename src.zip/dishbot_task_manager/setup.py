from setuptools import setup

package_name = 'dishbot_task_manager'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml', 'README.md']),
        ('share/' + package_name + '/launch', [
            'launch/task_manager.launch.py',
            'launch/table1_demo.launch.py',
        ]),
        ('share/' + package_name + '/config', ['config/task_manager.yaml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Dishbot Maintainers',
    maintainer_email='dishbot@example.com',
    description='Task orchestration actions for Dishbot restaurant collection.',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'task_manager_node = dishbot_task_manager.task_manager_node:main',
            'table1_demo = dishbot_task_manager.table1_demo_node:main',
        ],
    },
)
