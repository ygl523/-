import math
import time

import rclpy
import yaml
from ament_index_python.packages import get_package_share_directory
from dishbot_msgs.action import CollectDish, CycleCollect, GoToTable
from gazebo_msgs.msg import EntityState, ModelStates
from gazebo_msgs.srv import SetEntityState
from geometry_msgs.msg import PoseStamped, Twist
from rclpy.action import ActionClient, ActionServer, CancelResponse, GoalResponse
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from std_msgs.msg import String


def normalize_angle(angle):
    return math.atan2(math.sin(angle), math.cos(angle))


def yaw_from_quaternion(q):
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


def quaternion_from_yaw(yaw):
    half = yaw * 0.5
    return 0.0, 0.0, math.sin(half), math.cos(half)


class TaskManagerNode(Node):
    """Action-based task manager for the staged Dishbot demo.

    This stage intentionally uses the same deterministic cmd_vel route follower as
    the table_1 demo. Nav2 will replace this route follower in the next phase.
    """

    def __init__(self):
        super().__init__('task_manager_node')
        self.callback_group = ReentrantCallbackGroup()
        default_waypoints = (
            get_package_share_directory('dishbot_gazebo')
            + '/config/restaurant_waypoints.yaml'
        )
        self.declare_parameter('robot_model_name', 'dishbot')
        self.declare_parameter('waypoints_file', default_waypoints)
        self.declare_parameter('return_after_single_table', True)
        self.declare_parameter('xy_tolerance_m', 0.08)
        self.declare_parameter('yaw_tolerance_rad', 0.09)
        self.declare_parameter('collect_yaw_tolerance_rad', 0.30)
        self.declare_parameter('max_linear_mps', 0.65)
        self.declare_parameter('max_collect_linear_mps', 0.10)
        self.declare_parameter('max_angular_rps', 1.0)
        self.declare_parameter('linear_kp', 0.95)
        self.declare_parameter('angular_kp', 2.0)
        self.declare_parameter('goal_timeout_s', 95.0)
        self.declare_parameter('settle_s', 2.0)
        self.declare_parameter('settle_position_tolerance_m', 0.10)
        self.declare_parameter('settle_yaw_tolerance_rad', 0.04)
        self.declare_parameter('storage_plate_x', -0.18)
        self.declare_parameter('storage_plate_z', 0.66)
        self.declare_parameter('waste_bin_x', -0.08)
        self.declare_parameter('waste_bin_z', 0.28)

        self.robot_model_name = self.get_parameter('robot_model_name').value
        self.waypoints_file = self.get_parameter('waypoints_file').value
        self.return_after_single_table = bool(
            self.get_parameter('return_after_single_table').value
        )
        self.xy_tolerance_m = float(self.get_parameter('xy_tolerance_m').value)
        self.yaw_tolerance_rad = float(self.get_parameter('yaw_tolerance_rad').value)
        self.collect_yaw_tolerance_rad = float(
            self.get_parameter('collect_yaw_tolerance_rad').value
        )
        self.max_linear_mps = float(self.get_parameter('max_linear_mps').value)
        self.max_collect_linear_mps = float(self.get_parameter('max_collect_linear_mps').value)
        self.max_angular_rps = float(self.get_parameter('max_angular_rps').value)
        self.linear_kp = float(self.get_parameter('linear_kp').value)
        self.angular_kp = float(self.get_parameter('angular_kp').value)
        self.goal_timeout_s = float(self.get_parameter('goal_timeout_s').value)
        self.settle_s = float(self.get_parameter('settle_s').value)
        self.settle_position_tolerance_m = float(
            self.get_parameter('settle_position_tolerance_m').value
        )
        self.settle_yaw_tolerance_rad = float(
            self.get_parameter('settle_yaw_tolerance_rad').value
        )
        self.storage_plate_x = float(self.get_parameter('storage_plate_x').value)
        self.storage_plate_z = float(self.get_parameter('storage_plate_z').value)
        self.waste_bin_x = float(self.get_parameter('waste_bin_x').value)
        self.waste_bin_z = float(self.get_parameter('waste_bin_z').value)

        self.current_pose = None
        self.current_robot_z = 0.0
        self.collected_tables = []
        self.failed_tables = []
        self.carried_plates = []
        self.carried_waste = []
        self.active_goal = None
        self.waypoints = self._load_waypoints()

        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.task_state_pub = self.create_publisher(String, '/dishbot/task_state', 10)
        self.current_table_pub = self.create_publisher(String, '/dishbot/current_table', 10)
        self.collected_tables_pub = self.create_publisher(
            String,
            '/dishbot/collected_tables',
            10,
        )
        self.failure_report_pub = self.create_publisher(
            String,
            '/dishbot/failure_report',
            10,
        )
        self.set_entity_state_client = self.create_client(
            SetEntityState,
            '/set_entity_state',
            callback_group=self.callback_group,
        )
        self.create_subscription(
            ModelStates,
            '/model_states',
            self._model_states_cb,
            10,
            callback_group=self.callback_group,
        )
        self.collect_client = ActionClient(
            self,
            CollectDish,
            '/collect_dish',
            callback_group=self.callback_group,
        )
        self.go_to_table_server = ActionServer(
            self,
            GoToTable,
            '/go_to_table',
            execute_callback=self._execute_go_to_table,
            goal_callback=self._goal_callback,
            cancel_callback=self._cancel_callback,
            callback_group=self.callback_group,
        )
        self.cycle_collect_server = ActionServer(
            self,
            CycleCollect,
            '/cycle_collect',
            execute_callback=self._execute_cycle_collect,
            goal_callback=self._goal_callback,
            cancel_callback=self._cancel_callback,
            callback_group=self.callback_group,
        )
        self.get_logger().info('Task manager action servers ready: /go_to_table, /cycle_collect.')

    def _load_waypoints(self):
        with open(self.waypoints_file, 'r', encoding='utf-8') as stream:
            return yaml.safe_load(stream)

    def _model_states_cb(self, msg):
        try:
            index = msg.name.index(self.robot_model_name)
        except ValueError:
            return
        pose = msg.pose[index]
        self.current_pose = (
            pose.position.x,
            pose.position.y,
            yaw_from_quaternion(pose.orientation),
        )
        self.current_robot_z = pose.position.z

    def _goal_callback(self, _goal_request):
        return GoalResponse.ACCEPT

    def _cancel_callback(self, _goal_handle):
        self._publish_cmd(0.0, 0.0)
        self._publish_state('cancel_requested')
        return CancelResponse.ACCEPT

    def _execute_go_to_table(self, goal_handle):
        result = GoToTable.Result()
        table_id = goal_handle.request.table_id
        self.active_goal = goal_handle
        self._publish_current_table(table_id)
        feedback = GoToTable.Feedback()
        try:
            if not self._wait_ready():
                return self._finish_go_to_table(goal_handle, result, False, 'Simulation services are not ready.')
            success = self._collect_table(table_id, goal_handle, feedback)
            if success and self.return_after_single_table:
                success = self._return_to_dishwashing_room(table_id, goal_handle, feedback)
            message = f'Collected {table_id}.' if success else f'Failed to collect {table_id}.'
            return self._finish_go_to_table(goal_handle, result, success, message)
        finally:
            self.active_goal = None

    def _execute_cycle_collect(self, goal_handle):
        result = CycleCollect.Result()
        feedback = CycleCollect.Feedback()
        self.active_goal = goal_handle
        requested = list(goal_handle.request.table_ids)
        if not requested:
            requested = [f'table_{index}' for index in range(1, 7)]
        self.collected_tables = []
        self.failed_tables = []
        try:
            if not self._wait_ready():
                result.success = False
                result.message = 'Simulation services are not ready.'
                goal_handle.abort()
                return result
            total = max(len(requested), 1)
            last_table_id = None
            for index, table_id in enumerate(requested):
                if goal_handle.is_cancel_requested:
                    self._publish_cmd(0.0, 0.0)
                    result.success = False
                    result.collected_tables = self.collected_tables
                    result.failed_tables = self.failed_tables
                    result.message = 'Cycle collection canceled.'
                    goal_handle.canceled()
                    return result
                feedback.current_table = table_id
                feedback.state = 'collecting'
                feedback.progress = float(index / total)
                goal_handle.publish_feedback(feedback)
                self._publish_current_table(table_id)
                transition_route = self._route_between_tables(last_table_id, table_id)
                ok = self._collect_table(
                    table_id,
                    goal_handle,
                    feedback,
                    route_override=transition_route,
                )
                if ok:
                    self.collected_tables.append(table_id)
                else:
                    self.failed_tables.append(table_id)
                self._publish_collected()
                self._publish_failures()
                last_table_id = table_id
            feedback.current_table = 'dishwashing_room'
            feedback.state = 'returning'
            feedback.progress = 0.95
            goal_handle.publish_feedback(feedback)
            returned = self._return_to_dishwashing_room(last_table_id, goal_handle, feedback)
            result.success = returned and not self.failed_tables
            result.collected_tables = self.collected_tables
            result.failed_tables = self.failed_tables
            result.message = (
                'Cycle collection complete.'
                if result.success
                else 'Cycle collection finished with failures.'
            )
            if result.success:
                goal_handle.succeed()
            else:
                goal_handle.abort()
            self._publish_state(result.message)
            return result
        finally:
            self.active_goal = None

    def _finish_go_to_table(self, goal_handle, result, success, message):
        result.success = bool(success)
        result.message = message
        self._publish_state(message)
        if success:
            goal_handle.succeed()
        else:
            goal_handle.abort()
        return result

    def _wait_ready(self):
        if not self._wait_for_pose(10.0):
            self.get_logger().error('Robot pose from /model_states is unavailable.')
            return False
        if not self.collect_client.wait_for_server(timeout_sec=10.0):
            self.get_logger().error('/collect_dish action server is unavailable.')
            return False
        if not self.set_entity_state_client.wait_for_service(timeout_sec=5.0):
            self.get_logger().error('/set_entity_state service is unavailable.')
            return False
        return True

    def _wait_for_pose(self, timeout_s):
        deadline = time.monotonic() + timeout_s
        while rclpy.ok() and self.current_pose is None and time.monotonic() < deadline:
            time.sleep(0.05)
        return self.current_pose is not None

    def _collect_table(self, table_id, goal_handle, feedback, route_override=None):
        if table_id not in self.waypoints['tables']:
            self.get_logger().error(f'Unknown table_id: {table_id}')
            return False
        self._publish_state(f'navigating_to_{table_id}')
        table = self.waypoints['tables'][table_id]
        route = route_override if route_override is not None else table.get('route')
        route = route or [table['approach_pose']]
        for index, waypoint in enumerate(route):
            if not self._go_to_pose(waypoint, f'{table_id} route_{index + 1}', goal_handle, feedback):
                return False
            self._stop_for(0.3)
        if not self._go_to_pose(table['collect_pose'], f'{table_id} collect_pose', goal_handle, feedback):
            return False
        self._snap_robot_to_pose(table['collect_pose'])
        if not self._settle_before_collect():
            self.get_logger().warn(f'{table_id}: settle check failed, retrying collect pose once.')
            if not self._go_to_pose(table['collect_pose'], f'{table_id} collect_pose_retry', goal_handle, feedback):
                return False
            if not self._settle_before_collect():
                self.get_logger().error(f'{table_id}: robot did not settle before collection.')
                return False
        self._publish_state(f'collecting_{table_id}')
        if not self._collect_dish(table_id):
            return False
        self.carried_plates.append(f'plate_{table_id}')
        self.carried_waste.append(f'food_waste_{table_id}')
        retreat_pose = table.get('retreat_pose') or table.get('approach_pose')
        if retreat_pose:
            self._publish_state(f'retreating_from_{table_id}')
            if not self._go_to_pose(retreat_pose, f'{table_id} retreat_pose', goal_handle, feedback):
                return False
            self._stop_for(0.4)
        return True

    def _route_between_tables(self, previous_table_id, next_table_id):
        if next_table_id not in self.waypoints['tables']:
            return None
        next_table = self.waypoints['tables'][next_table_id]
        if not previous_table_id:
            return next_table.get('route') or [next_table['approach_pose']]
        previous_index = self._table_index(previous_table_id)
        next_index = self._table_index(next_table_id)
        if previous_index is None or next_index is None:
            return next_table.get('route') or [next_table['approach_pose']]
        previous_row = 0 if previous_index <= 3 else 1
        next_row = 0 if next_index <= 3 else 1
        if previous_row == next_row:
            travel_yaw = 0.0 if next_index > previous_index else math.pi
            if abs(next_index - previous_index) > 1:
                corridor_x = -4.45
                approach_y = -3.20 if next_row == 0 else 3.15
                outer_y = -3.45 if next_row == 0 else 3.45
                return [
                    self._waypoint(corridor_x, approach_y, math.pi),
                    self._waypoint(corridor_x, outer_y, travel_yaw),
                    self._waypoint(next_table['approach_pose']['x'], outer_y, travel_yaw),
                    self._waypoint(
                        next_table['approach_pose']['x'],
                        next_table['approach_pose']['y'],
                        -math.pi / 2.0 if next_row == 1 else math.pi / 2.0,
                    ),
                    next_table['approach_pose'],
                ]
            return [
                self._waypoint(
                    next_table['approach_pose']['x'],
                    next_table['approach_pose']['y'],
                    travel_yaw,
                ),
                next_table['approach_pose'],
            ]

        corridor_x = -4.45
        source_y = -3.20 if previous_row == 0 else 3.15
        target_y = -3.20 if next_row == 0 else 3.15
        vertical_yaw = math.pi / 2.0 if target_y > source_y else -math.pi / 2.0
        horizontal_yaw = 0.0 if next_table['approach_pose']['x'] > corridor_x else math.pi
        return [
            self._waypoint(corridor_x, source_y, math.pi),
            self._waypoint(corridor_x, 0.0, vertical_yaw),
            self._waypoint(corridor_x, target_y, horizontal_yaw),
            self._waypoint(
                next_table['approach_pose']['x'],
                next_table['approach_pose']['y'],
                horizontal_yaw,
            ),
            next_table['approach_pose'],
        ]

    @staticmethod
    def _waypoint(x, y, yaw):
        return {'x': float(x), 'y': float(y), 'yaw': float(yaw)}

    @staticmethod
    def _table_index(table_id):
        try:
            prefix, number = table_id.split('_', 1)
            if prefix != 'table':
                return None
            return int(number)
        except (TypeError, ValueError):
            return None

    def _go_to_pose(self, goal, label, goal_handle=None, feedback=None):
        self.get_logger().info(
            f'Going to {label}: x={goal["x"]:.2f}, y={goal["y"]:.2f}, yaw={goal["yaw"]:.2f}'
        )
        deadline = time.monotonic() + self.goal_timeout_s
        while rclpy.ok() and time.monotonic() < deadline:
            if goal_handle is not None and goal_handle.is_cancel_requested:
                self._publish_cmd(0.0, 0.0)
                return False
            if self.current_pose is None:
                time.sleep(0.02)
                continue
            self._keep_collected_entities()
            x, y, yaw = self.current_pose
            dx = float(goal['x']) - x
            dy = float(goal['y']) - y
            distance = math.hypot(dx, dy)
            target_heading = math.atan2(dy, dx)
            heading_error = normalize_angle(target_heading - yaw)
            yaw_error = normalize_angle(float(goal['yaw']) - yaw)
            if feedback is not None and hasattr(feedback, 'distance_remaining'):
                feedback.state = label
                feedback.distance_remaining = float(distance)
                goal_handle.publish_feedback(feedback)
            yaw_tolerance = (
                self.collect_yaw_tolerance_rad
                if 'collect_pose' in label or 'return_route_1' in label
                else self.yaw_tolerance_rad
            )
            if distance <= self.xy_tolerance_m:
                if not self._requires_goal_yaw(label) or abs(yaw_error) <= yaw_tolerance:
                    self._brake_burst()
                    self.get_logger().info(f'Reached {label}.')
                    return True
                self._publish_cmd(0.0, self._clamp(self.angular_kp * yaw_error, self.max_angular_rps))
                time.sleep(0.02)
                continue
            linear_limit = (
                self.max_collect_linear_mps
                if 'collect_pose' in label or 'retreat_pose' in label
                else self.max_linear_mps
            )
            linear = 0.0 if abs(heading_error) > 0.35 else self._clamp(self.linear_kp * distance, linear_limit)
            angular = self._clamp(self.angular_kp * heading_error, self.max_angular_rps)
            self._publish_cmd(linear, angular)
            time.sleep(0.02)
        self._publish_cmd(0.0, 0.0)
        self.get_logger().error(f'Timed out going to {label}.')
        return False

    @staticmethod
    def _requires_goal_yaw(label):
        return 'collect_pose' in label or 'dishwashing_room return_pose' in label

    def _collect_dish(self, table_id):
        goal = CollectDish.Goal()
        goal.table_id = table_id
        goal.plate_pose = PoseStamped()
        send_future = self.collect_client.send_goal_async(goal)
        if not self._wait_future(send_future, 5.0):
            self.get_logger().error('Timed out sending CollectDish goal.')
            return False
        collect_handle = send_future.result()
        if collect_handle is None or not collect_handle.accepted:
            self.get_logger().error('CollectDish goal rejected.')
            return False
        result_future = collect_handle.get_result_async()
        if not self._wait_future(result_future, 35.0):
            self.get_logger().error('Timed out waiting for CollectDish result.')
            return False
        result = result_future.result().result
        if not result.success:
            self.get_logger().error(f'CollectDish failed: {result.message}')
            return False
        return True

    def _return_to_dishwashing_room(self, table_id, goal_handle, feedback):
        self._publish_state('returning_to_dishwashing_room')
        route = []
        if table_id and table_id in self.waypoints['tables']:
            route = self.waypoints['tables'][table_id].get('return_route', [])
        if not route:
            route = [self.waypoints['dishwashing_room']['return_pose']]
        for index, waypoint in enumerate(route):
            if not self._go_to_pose(waypoint, f'return_route_{index + 1}', goal_handle, feedback):
                return False
            self._stop_for(0.3)
        return_pose = self.waypoints['dishwashing_room']['return_pose']
        if route[-1] != return_pose:
            return self._go_to_pose(return_pose, 'dishwashing_room return_pose', goal_handle, feedback)
        self._stop_for(self.settle_s)
        return True

    def _wait_future(self, future, timeout_s):
        deadline = time.monotonic() + timeout_s
        while rclpy.ok() and not future.done() and time.monotonic() < deadline:
            time.sleep(0.05)
        return future.done() and future.result() is not None

    def _settle_before_collect(self):
        start_pose = self.current_pose
        if start_pose is None:
            return False
        end_time = time.monotonic() + self.settle_s
        while rclpy.ok() and time.monotonic() < end_time:
            self._publish_cmd(0.0, 0.0)
            time.sleep(0.05)
        if self.current_pose is None:
            return False
        dx = self.current_pose[0] - start_pose[0]
        dy = self.current_pose[1] - start_pose[1]
        dyaw = normalize_angle(self.current_pose[2] - start_pose[2])
        return (
            math.hypot(dx, dy) <= self.settle_position_tolerance_m
            and abs(dyaw) <= self.settle_yaw_tolerance_rad
        )

    def _stop_for(self, duration_s):
        end_time = time.monotonic() + duration_s
        while rclpy.ok() and time.monotonic() < end_time:
            self._publish_cmd(0.0, 0.0)
            self._keep_collected_entities()
            time.sleep(0.05)

    def _brake_burst(self):
        for _ in range(8):
            self._publish_cmd(0.0, 0.0)
            time.sleep(0.03)

    def _publish_cmd(self, linear, angular):
        msg = Twist()
        msg.linear.x = float(linear)
        msg.angular.z = float(angular)
        self.cmd_pub.publish(msg)

    def _keep_collected_entities(self):
        if self.current_pose is None:
            return
        y_offsets = [-0.13, 0.0, 0.13, -0.07, 0.07, 0.0]
        for index, plate in enumerate(self.carried_plates):
            self._set_relative_entity(
                plate,
                self.storage_plate_x,
                y_offsets[index % len(y_offsets)],
                self.storage_plate_z + 0.012 * index,
            )
        for index, waste in enumerate(self.carried_waste):
            self._set_relative_entity(
                waste,
                self.waste_bin_x,
                y_offsets[index % len(y_offsets)],
                self.waste_bin_z + 0.010 * index,
            )

    def _set_relative_entity(self, name, rel_x, rel_y, rel_z):
        if self.current_pose is None or not self.set_entity_state_client.service_is_ready():
            return
        x, y, yaw = self.current_pose
        world_x = x + rel_x * math.cos(yaw) - rel_y * math.sin(yaw)
        world_y = y + rel_x * math.sin(yaw) + rel_y * math.cos(yaw)
        qx, qy, qz, qw = quaternion_from_yaw(yaw)
        state = EntityState()
        state.name = name
        state.reference_frame = 'world'
        state.pose.position.x = world_x
        state.pose.position.y = world_y
        state.pose.position.z = self.current_robot_z + rel_z
        state.pose.orientation.x = qx
        state.pose.orientation.y = qy
        state.pose.orientation.z = qz
        state.pose.orientation.w = qw
        request = SetEntityState.Request()
        request.state = state
        self.set_entity_state_client.call_async(request)

    def _snap_robot_to_pose(self, pose):
        if not self.set_entity_state_client.service_is_ready():
            return
        state = EntityState()
        state.name = self.robot_model_name
        state.reference_frame = 'world'
        state.pose.position.x = float(pose['x'])
        state.pose.position.y = float(pose['y'])
        state.pose.position.z = self.current_robot_z
        qx, qy, qz, qw = quaternion_from_yaw(float(pose['yaw']))
        state.pose.orientation.x = qx
        state.pose.orientation.y = qy
        state.pose.orientation.z = qz
        state.pose.orientation.w = qw
        request = SetEntityState.Request()
        request.state = state
        self.set_entity_state_client.call_async(request)
        self.current_pose = (float(pose['x']), float(pose['y']), float(pose['yaw']))

    def _publish_state(self, state):
        self.task_state_pub.publish(String(data=str(state)))

    def _publish_current_table(self, table_id):
        self.current_table_pub.publish(String(data=str(table_id)))

    def _publish_collected(self):
        self.collected_tables_pub.publish(String(data=','.join(self.collected_tables)))

    def _publish_failures(self):
        self.failure_report_pub.publish(String(data=','.join(self.failed_tables)))

    @staticmethod
    def _clamp(value, limit):
        return max(-limit, min(limit, value))


def main(args=None):
    rclpy.init(args=args)
    node = TaskManagerNode()
    executor = MultiThreadedExecutor()
    executor.add_node(node)
    try:
        executor.spin()
    finally:
        node.destroy_node()
        rclpy.shutdown()
