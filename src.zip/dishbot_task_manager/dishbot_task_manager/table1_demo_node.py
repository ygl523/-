import math
import time

import rclpy
import yaml
from ament_index_python.packages import get_package_share_directory
from dishbot_msgs.action import CollectDish
from gazebo_msgs.msg import EntityState, ModelStates
from gazebo_msgs.srv import SetEntityState
from geometry_msgs.msg import PoseStamped, Twist
from rclpy.action import ActionClient
from rclpy.node import Node


def normalize_angle(angle):
    return math.atan2(math.sin(angle), math.cos(angle))


def yaw_from_quaternion(q):
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


def quaternion_from_yaw(yaw):
    half = yaw * 0.5
    return 0.0, 0.0, math.sin(half), math.cos(half)


class Table1DemoNode(Node):
    """Minimal table_1 collection demo before full Nav2 integration."""

    def __init__(self):
        super().__init__('table1_demo_node')
        default_waypoints = (
            get_package_share_directory('dishbot_gazebo')
            + '/config/restaurant_waypoints.yaml'
        )
        self.declare_parameter('table_id', 'table_1')
        self.declare_parameter('robot_model_name', 'dishbot')
        self.declare_parameter('waypoints_file', default_waypoints)
        self.declare_parameter('xy_tolerance_m', 0.08)
        self.declare_parameter('yaw_tolerance_rad', 0.09)
        self.declare_parameter('collect_yaw_tolerance_rad', 0.30)
        self.declare_parameter('max_linear_mps', 0.65)
        self.declare_parameter('max_collect_linear_mps', 0.10)
        self.declare_parameter('max_angular_rps', 1.0)
        self.declare_parameter('linear_kp', 0.95)
        self.declare_parameter('angular_kp', 2.0)
        self.declare_parameter('goal_timeout_s', 95.0)
        self.declare_parameter('settle_s', 3.0)
        self.declare_parameter('settle_position_tolerance_m', 0.08)
        self.declare_parameter('settle_yaw_tolerance_rad', 0.02)
        self.declare_parameter('storage_plate_x', -0.18)
        self.declare_parameter('storage_plate_y', 0.0)
        self.declare_parameter('storage_plate_z', 0.66)
        self.declare_parameter('waste_bin_x', -0.08)
        self.declare_parameter('waste_bin_y', 0.0)
        self.declare_parameter('waste_bin_z', 0.28)

        self.table_id = self.get_parameter('table_id').value
        self.robot_model_name = self.get_parameter('robot_model_name').value
        self.waypoints_file = self.get_parameter('waypoints_file').value
        self.xy_tolerance_m = float(self.get_parameter('xy_tolerance_m').value)
        self.yaw_tolerance_rad = float(self.get_parameter('yaw_tolerance_rad').value)
        self.collect_yaw_tolerance_rad = float(
            self.get_parameter('collect_yaw_tolerance_rad').value
        )
        self.max_linear_mps = float(self.get_parameter('max_linear_mps').value)
        self.max_collect_linear_mps = float(self.get_parameter('max_collect_linear_mps').value)
        self.max_angular_rps = float(self.get_parameter('max_angular_rps').value)
        self.linear_kp = float(self.get_parameter('linear_kp').value)
        self.angular_kp = float(self.get_parameter('angular_kp').value)
        self.goal_timeout_s = float(self.get_parameter('goal_timeout_s').value)
        self.settle_s = float(self.get_parameter('settle_s').value)
        self.settle_position_tolerance_m = float(
            self.get_parameter('settle_position_tolerance_m').value
        )
        self.settle_yaw_tolerance_rad = float(
            self.get_parameter('settle_yaw_tolerance_rad').value
        )
        self.storage_plate_x = float(self.get_parameter('storage_plate_x').value)
        self.storage_plate_y = float(self.get_parameter('storage_plate_y').value)
        self.storage_plate_z = float(self.get_parameter('storage_plate_z').value)
        self.waste_bin_x = float(self.get_parameter('waste_bin_x').value)
        self.waste_bin_y = float(self.get_parameter('waste_bin_y').value)
        self.waste_bin_z = float(self.get_parameter('waste_bin_z').value)

        self.current_pose = None
        self.current_robot_z = 0.0
        self.carried_plate_name = ''
        self.carried_waste_name = ''
        self.collected_once = False
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.set_entity_state_client = self.create_client(SetEntityState, '/set_entity_state')
        self.create_subscription(ModelStates, '/model_states', self._model_states_cb, 10)
        self.collect_client = ActionClient(self, CollectDish, '/collect_dish')
        self.waypoints = self._load_waypoints()

    def _load_waypoints(self):
        with open(self.waypoints_file, 'r', encoding='utf-8') as stream:
            return yaml.safe_load(stream)

    def _model_states_cb(self, msg):
        try:
            index = msg.name.index(self.robot_model_name)
        except ValueError:
            return
        pose = msg.pose[index]
        self.current_pose = (
            pose.position.x,
            pose.position.y,
            yaw_from_quaternion(pose.orientation),
        )
        self.current_robot_z = pose.position.z

    def run(self):
        self.get_logger().info(f'Starting minimal collection demo for {self.table_id}.')
        if self.table_id not in self.waypoints['tables']:
            self.get_logger().error(f'Unknown table_id: {self.table_id}')
            return 1
        if not self._wait_for_pose(timeout_s=10.0):
            self.get_logger().error('Robot pose from /model_states is unavailable.')
            return 1
        if not self.collect_client.wait_for_server(timeout_sec=10.0):
            self.get_logger().error('/collect_dish action server is unavailable.')
            return 1

        table = self.waypoints['tables'][self.table_id]
        route = table.get('route', [])
        for index, waypoint in enumerate(route):
            if not self._go_to_pose(waypoint, f'{self.table_id} route_{index + 1}'):
                return 1
            self._stop_for(0.3)

        if not route:
            if not self._go_to_pose(table['approach_pose'], f'{self.table_id} approach_pose'):
                return 1
        if not self._go_to_pose(table['collect_pose'], f'{self.table_id} collect_pose'):
            return 1
        self._snap_robot_to_pose(table['collect_pose'])

        if not self._settle_before_collect():
            self.get_logger().warn('Robot did not settle; re-aligning collect pose once.')
            if not self._go_to_pose(table['collect_pose'], f'{self.table_id} collect_pose_retry'):
                return 1
            if not self._settle_before_collect():
                self.get_logger().error('Robot did not settle before collection after retry.')
                return 1
        if not self._collect_dish():
            return 1
        self.carried_plate_name = f'plate_{self.table_id}'
        self.carried_waste_name = f'food_waste_{self.table_id}'
        retreat_pose = table.get('retreat_pose')
        if retreat_pose:
            if not self._go_to_pose(retreat_pose, f'{self.table_id} retreat_pose'):
                return 1
            self._stop_for(0.4)

        for index, waypoint in enumerate(table.get('return_route', [])):
            if not self._go_to_pose(waypoint, f'{self.table_id} return_route_{index + 1}'):
                return 1
            self._stop_for(0.3)
        return_pose = self.waypoints['dishwashing_room']['return_pose']
        if not self._go_to_pose(return_pose, 'dishwashing_room return_pose'):
            return 1
        self._stop_for(self.settle_s)
        self.get_logger().info('Minimal table_1 demo complete.')
        return 0

    def _wait_for_pose(self, timeout_s):
        deadline = time.monotonic() + timeout_s
        while rclpy.ok() and self.current_pose is None and time.monotonic() < deadline:
            rclpy.spin_once(self, timeout_sec=0.1)
        return self.current_pose is not None

    def _go_to_pose(self, goal, label):
        self.get_logger().info(
            f'Going to {label}: x={goal["x"]:.2f}, y={goal["y"]:.2f}, yaw={goal["yaw"]:.2f}'
        )
        deadline = time.monotonic() + self.goal_timeout_s
        while rclpy.ok() and time.monotonic() < deadline:
            rclpy.spin_once(self, timeout_sec=0.02)
            if self.current_pose is None:
                continue
            self._keep_carried_plate_in_storage()
            self._keep_carried_waste_in_bin()
            x, y, yaw = self.current_pose
            dx = float(goal['x']) - x
            dy = float(goal['y']) - y
            distance = math.hypot(dx, dy)
            target_heading = math.atan2(dy, dx)
            heading_error = normalize_angle(target_heading - yaw)
            yaw_error = normalize_angle(float(goal['yaw']) - yaw)

            yaw_tolerance = (
                self.collect_yaw_tolerance_rad
                if 'collect_pose' in label or 'return_route_1' in label
                else self.yaw_tolerance_rad
            )
            if distance <= self.xy_tolerance_m:
                if abs(yaw_error) <= yaw_tolerance or 'collect_pose' in label:
                    self._brake_burst()
                    self.get_logger().info(f'Reached {label}.')
                    return True
                self._publish_cmd(0.0, self._clamp(self.angular_kp * yaw_error, self.max_angular_rps))
                continue

            linear_limit = (
                self.max_collect_linear_mps
                if 'collect_pose' in label or 'retreat_pose' in label
                else self.max_linear_mps
            )
            if abs(heading_error) > 0.35:
                linear = 0.0
            else:
                linear = self._clamp(self.linear_kp * distance, linear_limit)
            angular = self._clamp(self.angular_kp * heading_error, self.max_angular_rps)
            self._publish_cmd(linear, angular)

        self._publish_cmd(0.0, 0.0)
        self.get_logger().error(f'Timed out going to {label}.')
        return False

    def _brake_burst(self):
        for _ in range(8):
            self._publish_cmd(0.0, 0.0)
            rclpy.spin_once(self, timeout_sec=0.01)
            time.sleep(0.03)

    def _collect_dish(self):
        if self.collected_once:
            self.get_logger().warn(f'{self.table_id} has already been collected in this run.')
            return False
        self.get_logger().info(f'Calling /collect_dish for {self.table_id}.')
        goal = CollectDish.Goal()
        goal.table_id = self.table_id
        goal.plate_pose = PoseStamped()
        send_future = self.collect_client.send_goal_async(
            goal,
            feedback_callback=self._collect_feedback_cb,
        )
        if not self._wait_future(send_future, timeout_s=5.0):
            self.get_logger().error('Timed out sending CollectDish goal.')
            return False
        goal_handle = send_future.result()
        if not goal_handle.accepted:
            self.get_logger().error('CollectDish goal rejected.')
            return False
        result_future = goal_handle.get_result_async()
        deadline = time.monotonic() + 30.0
        while rclpy.ok() and not result_future.done() and time.monotonic() < deadline:
            self._publish_cmd(0.0, 0.0)
            rclpy.spin_once(self, timeout_sec=0.05)
            time.sleep(0.05)
        if not result_future.done() or result_future.result() is None:
            self.get_logger().error('Timed out waiting for CollectDish result.')
            return False
        result = result_future.result().result
        if not result.success:
            self.get_logger().error(f'CollectDish failed: {result.message}')
            return False
        self.collected_once = True
        self.get_logger().info(f'CollectDish succeeded: {result.message}')
        return True

    def _collect_feedback_cb(self, msg):
        feedback = msg.feedback
        self.get_logger().info(
            f'CollectDish feedback: {feedback.state} {feedback.progress:.2f}'
        )

    def _wait_future(self, future, timeout_s):
        deadline = time.monotonic() + timeout_s
        while rclpy.ok() and not future.done() and time.monotonic() < deadline:
            rclpy.spin_once(self, timeout_sec=0.05)
        return future.done() and future.result() is not None

    def _stop_for(self, duration_s):
        end_time = time.monotonic() + duration_s
        while rclpy.ok() and time.monotonic() < end_time:
            self._publish_cmd(0.0, 0.0)
            self._keep_carried_plate_in_storage()
            self._keep_carried_waste_in_bin()
            rclpy.spin_once(self, timeout_sec=0.02)
            time.sleep(0.05)

    def _settle_before_collect(self):
        self.get_logger().info(f'Settling for {self.settle_s:.1f}s before collection.')
        start_pose = self.current_pose
        if start_pose is None:
            return False
        end_time = time.monotonic() + self.settle_s
        while rclpy.ok() and time.monotonic() < end_time:
            self._publish_cmd(0.0, 0.0)
            rclpy.spin_once(self, timeout_sec=0.05)
            time.sleep(0.05)
        if self.current_pose is None:
            return False
        dx = self.current_pose[0] - start_pose[0]
        dy = self.current_pose[1] - start_pose[1]
        dyaw = normalize_angle(self.current_pose[2] - start_pose[2])
        drift = math.hypot(dx, dy)
        self.get_logger().info(
            f'Settle check: drift={drift:.3f}m, yaw_drift={dyaw:.3f}rad.'
        )
        return (
            drift <= self.settle_position_tolerance_m
            and abs(dyaw) <= self.settle_yaw_tolerance_rad
        )

    def _publish_cmd(self, linear, angular):
        msg = Twist()
        msg.linear.x = float(linear)
        msg.angular.z = float(angular)
        self.cmd_pub.publish(msg)

    @staticmethod
    def _clamp(value, limit):
        return max(-limit, min(limit, value))

    def _keep_carried_plate_in_storage(self):
        if not self.carried_plate_name or self.current_pose is None:
            return
        if not self.set_entity_state_client.service_is_ready():
            return
        x, y, yaw = self.current_pose
        world_x = (
            x
            + self.storage_plate_x * math.cos(yaw)
            - self.storage_plate_y * math.sin(yaw)
        )
        world_y = (
            y
            + self.storage_plate_x * math.sin(yaw)
            + self.storage_plate_y * math.cos(yaw)
        )
        qx = 0.0
        qy = 0.0
        qz = math.sin(yaw * 0.5)
        qw = math.cos(yaw * 0.5)
        state = EntityState()
        state.name = self.carried_plate_name
        state.reference_frame = 'world'
        state.pose.position.x = world_x
        state.pose.position.y = world_y
        state.pose.position.z = self.current_robot_z + self.storage_plate_z
        state.pose.orientation.x = qx
        state.pose.orientation.y = qy
        state.pose.orientation.z = qz
        state.pose.orientation.w = qw
        request = SetEntityState.Request()
        request.state = state
        self.set_entity_state_client.call_async(request)

    def _keep_carried_waste_in_bin(self):
        if not self.carried_waste_name or self.current_pose is None:
            return
        self._set_relative_entity(
            self.carried_waste_name,
            self.waste_bin_x,
            self.waste_bin_y,
            self.waste_bin_z,
        )

    def _set_relative_entity(self, name, rel_x, rel_y, rel_z):
        if self.current_pose is None or not self.set_entity_state_client.service_is_ready():
            return
        x, y, yaw = self.current_pose
        world_x = x + rel_x * math.cos(yaw) - rel_y * math.sin(yaw)
        world_y = y + rel_x * math.sin(yaw) + rel_y * math.cos(yaw)
        qx, qy, qz, qw = quaternion_from_yaw(yaw)
        state = EntityState()
        state.name = name
        state.reference_frame = 'world'
        state.pose.position.x = world_x
        state.pose.position.y = world_y
        state.pose.position.z = self.current_robot_z + rel_z
        state.pose.orientation.x = qx
        state.pose.orientation.y = qy
        state.pose.orientation.z = qz
        state.pose.orientation.w = qw
        request = SetEntityState.Request()
        request.state = state
        self.set_entity_state_client.call_async(request)

    def _snap_robot_to_pose(self, pose):
        if not self.set_entity_state_client.wait_for_service(timeout_sec=2.0):
            self.get_logger().warn('Cannot snap robot: /set_entity_state unavailable.')
            return
        self._publish_cmd(0.0, 0.0)
        qx, qy, qz, qw = quaternion_from_yaw(float(pose['yaw']))
        state = EntityState()
        state.name = self.robot_model_name
        state.reference_frame = 'world'
        state.pose.position.x = float(pose['x'])
        state.pose.position.y = float(pose['y'])
        state.pose.position.z = self.current_robot_z
        state.pose.orientation.x = qx
        state.pose.orientation.y = qy
        state.pose.orientation.z = qz
        state.pose.orientation.w = qw
        request = SetEntityState.Request()
        request.state = state
        for _ in range(3):
            self.set_entity_state_client.call_async(request)
            rclpy.spin_once(self, timeout_sec=0.05)
            time.sleep(0.05)
        self.current_pose = (float(pose['x']), float(pose['y']), float(pose['yaw']))
        self.get_logger().info('Snapped robot to collect pose for stable collection.')


def main(args=None):
    rclpy.init(args=args)
    node = Table1DemoNode()
    try:
        exit_code = node.run()
    finally:
        node._publish_cmd(0.0, 0.0)
        node.destroy_node()
        rclpy.shutdown()
    raise SystemExit(exit_code)
