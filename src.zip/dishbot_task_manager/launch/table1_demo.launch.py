from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    table_id = LaunchConfiguration('table_id')
    waypoints_file = PathJoinSubstitution([
        FindPackageShare('dishbot_gazebo'),
        'config',
        'restaurant_waypoints.yaml',
    ])

    return LaunchDescription([
        DeclareLaunchArgument(
            'table_id',
            default_value='table_1',
            description='Table to collect in the minimal demo.',
        ),
        Node(
            package='dishbot_task_manager',
            executable='table1_demo',
            name='table1_demo_node',
            output='screen',
            parameters=[{
                'table_id': table_id,
                'waypoints_file': waypoints_file,
                'use_sim_time': True,
            }],
        ),
    ])
