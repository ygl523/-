from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    waypoints_file = PathJoinSubstitution([
        FindPackageShare('dishbot_gazebo'),
        'config',
        'restaurant_waypoints.yaml',
    ])
    return LaunchDescription([
        DeclareLaunchArgument(
            'return_after_single_table',
            default_value='true',
            description='Return to the dishwashing room after /go_to_table.',
        ),
        Node(
            package='dishbot_task_manager',
            executable='task_manager_node',
            name='task_manager_node',
            output='screen',
            parameters=[{
                'use_sim_time': True,
                'waypoints_file': waypoints_file,
                'return_after_single_table': LaunchConfiguration('return_after_single_table'),
            }],
        ),
    ])
