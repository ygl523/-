from setuptools import setup

package_name = 'dishbot_tests'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml', 'README.md']),
        ('share/' + package_name + '/launch', ['launch/tests.launch.py']),
        ('share/' + package_name + '/config', ['config/tests.yaml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Dishbot Maintainers',
    maintainer_email='dishbot@example.com',
    description='Integration and acceptance tests for Dishbot.',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'test_spawn_robot = dishbot_tests.test_spawn_robot:main',
            'test_drive_stability = dishbot_tests.test_drive_stability:main',
            'test_pusher_motion = dishbot_tests.test_pusher_motion:main',
            'test_collect_table_1 = dishbot_tests.test_collect_table_1:main',
            'test_cycle_collect = dishbot_tests.test_cycle_collect:main',
        ],
    },
)
