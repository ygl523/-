import time

import rclpy
from gazebo_msgs.srv import GetEntityState


def wait_future(node, future, timeout_s):
    deadline = time.monotonic() + float(timeout_s)
    while rclpy.ok() and not future.done() and time.monotonic() < deadline:
        rclpy.spin_once(node, timeout_sec=0.05)
    return future.done() and future.result() is not None


def wait_for_entity_state(node, client, name, reference_frame, timeout_s=2.0):
    if not client.wait_for_service(timeout_sec=timeout_s):
        node.get_logger().error('/get_entity_state service is unavailable.')
        return None

    request = GetEntityState.Request()
    request.name = name
    request.reference_frame = reference_frame
    future = client.call_async(request)
    if not wait_future(node, future, timeout_s):
        node.get_logger().error(f'Timed out reading Gazebo entity {name}.')
        return None
    response = future.result()
    if response is None or not response.success:
        node.get_logger().error(f'Gazebo entity {name} is unavailable.')
        return None
    return response.state


def plate_is_in_storage(node, client, table_id, robot_entity):
    name = f'plate_{table_id}'
    state = wait_for_entity_state(node, client, name, robot_entity)
    if state is None:
        return False

    p = state.pose.position
    in_storage = -0.45 <= p.x <= 0.25 and abs(p.y) <= 0.32 and 0.15 <= p.z <= 0.85
    node.get_logger().info(
        f'{name} relative to {robot_entity}: '
        f'x={p.x:.3f}, y={p.y:.3f}, z={p.z:.3f}, in_storage={in_storage}'
    )
    return in_storage
