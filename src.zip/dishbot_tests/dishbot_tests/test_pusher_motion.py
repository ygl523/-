def main():
    print('test_pusher_motion scaffold')
