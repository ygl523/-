def main():
    print('test_spawn_robot scaffold')
