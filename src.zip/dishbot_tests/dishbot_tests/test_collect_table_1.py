import sys

import rclpy
from dishbot_msgs.action import GoToTable
from gazebo_msgs.srv import GetEntityState
from rclpy.action import ActionClient
from rclpy.node import Node

from dishbot_tests.validation_common import plate_is_in_storage, wait_future


class CollectTableValidation(Node):
    def __init__(self):
        super().__init__('test_collect_table_1')
        self.declare_parameter('table_id', 'table_1')
        self.declare_parameter('timeout_s', 140.0)
        self.declare_parameter('robot_entity', 'dishbot')
        self.declare_parameter('check_plate_in_storage', True)
        self.client = ActionClient(self, GoToTable, '/go_to_table')
        self.entity_state_client = self.create_client(GetEntityState, '/get_entity_state')

    def run(self):
        table_id = self.get_parameter('table_id').value
        timeout_s = float(self.get_parameter('timeout_s').value)
        self.get_logger().info(f'Waiting for /go_to_table action server for {timeout_s:.1f}s.')
        if not self.client.wait_for_server(timeout_sec=timeout_s):
            self.get_logger().error('/go_to_table action server is unavailable.')
            return 1

        goal = GoToTable.Goal()
        goal.table_id = table_id
        send_future = self.client.send_goal_async(
            goal,
            feedback_callback=self._feedback_callback,
        )
        if not wait_future(self, send_future, 5.0):
            self.get_logger().error('Timed out sending GoToTable goal.')
            return 1

        goal_handle = send_future.result()
        if goal_handle is None or not goal_handle.accepted:
            self.get_logger().error('GoToTable goal was rejected.')
            return 1

        result_future = goal_handle.get_result_async()
        if not wait_future(self, result_future, timeout_s):
            self.get_logger().error('Timed out waiting for GoToTable result.')
            return 1

        result = result_future.result().result
        if not result.success:
            self.get_logger().error(f'GoToTable failed: {result.message}')
            return 1

        self.get_logger().info(f'GoToTable succeeded: {result.message}')
        if bool(self.get_parameter('check_plate_in_storage').value):
            robot_entity = self.get_parameter('robot_entity').value
            if not plate_is_in_storage(self, self.entity_state_client, table_id, robot_entity):
                self.get_logger().error(f'{table_id} plate was not found in robot storage.')
                return 1
        return 0

    def _feedback_callback(self, feedback_msg):
        feedback = feedback_msg.feedback
        self.get_logger().info(
            f'GoToTable feedback: state={feedback.state}, '
            f'distance_remaining={feedback.distance_remaining:.2f}'
        )


def main(args=None):
    rclpy.init(args=args)
    node = CollectTableValidation()
    try:
        exit_code = node.run()
    finally:
        node.destroy_node()
        rclpy.shutdown()
    sys.exit(exit_code)
