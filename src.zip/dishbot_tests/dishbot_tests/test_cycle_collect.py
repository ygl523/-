import sys

import rclpy
from dishbot_msgs.action import CycleCollect
from gazebo_msgs.srv import GetEntityState
from rclpy.action import ActionClient
from rclpy.node import Node

from dishbot_tests.validation_common import plate_is_in_storage, wait_future


class CycleCollectValidation(Node):
    def __init__(self):
        super().__init__('test_cycle_collect')
        self.declare_parameter('table_ids', 'table_1,table_2,table_3,table_4,table_5,table_6')
        self.declare_parameter('timeout_s', 520.0)
        self.declare_parameter('robot_entity', 'dishbot')
        self.declare_parameter('check_plates_in_storage', True)
        self.client = ActionClient(self, CycleCollect, '/cycle_collect')
        self.entity_state_client = self.create_client(GetEntityState, '/get_entity_state')

    def run(self):
        table_ids = self._table_ids()
        timeout_s = float(self.get_parameter('timeout_s').value)
        self.get_logger().info(
            f'Waiting for /cycle_collect action server for {timeout_s:.1f}s. '
            f'tables={table_ids}'
        )
        if not self.client.wait_for_server(timeout_sec=timeout_s):
            self.get_logger().error('/cycle_collect action server is unavailable.')
            return 1

        goal = CycleCollect.Goal()
        goal.table_ids = table_ids
        send_future = self.client.send_goal_async(
            goal,
            feedback_callback=self._feedback_callback,
        )
        if not wait_future(self, send_future, 5.0):
            self.get_logger().error('Timed out sending CycleCollect goal.')
            return 1

        goal_handle = send_future.result()
        if goal_handle is None or not goal_handle.accepted:
            self.get_logger().error('CycleCollect goal was rejected.')
            return 1

        result_future = goal_handle.get_result_async()
        if not wait_future(self, result_future, timeout_s):
            self.get_logger().error('Timed out waiting for CycleCollect result.')
            return 1

        result = result_future.result().result
        self.get_logger().info(
            f'CycleCollect result: success={result.success}, '
            f'collected={list(result.collected_tables)}, '
            f'failed={list(result.failed_tables)}, message={result.message}'
        )
        if not result.success:
            return 1

        expected = set(table_ids)
        collected = set(result.collected_tables)
        if expected and collected != expected:
            self.get_logger().error(
                f'Collected table mismatch: expected={sorted(expected)}, '
                f'actual={sorted(collected)}'
            )
            return 1

        if bool(self.get_parameter('check_plates_in_storage').value):
            robot_entity = self.get_parameter('robot_entity').value
            for table_id in table_ids:
                if not plate_is_in_storage(self, self.entity_state_client, table_id, robot_entity):
                    self.get_logger().error(f'{table_id} plate was not found in robot storage.')
                    return 1
        return 0

    def _table_ids(self):
        raw_value = self.get_parameter('table_ids').value
        if isinstance(raw_value, str):
            return [item.strip() for item in raw_value.split(',') if item.strip()]
        return list(raw_value)

    def _feedback_callback(self, feedback_msg):
        feedback = feedback_msg.feedback
        self.get_logger().info(
            f'CycleCollect feedback: table={feedback.current_table}, '
            f'state={feedback.state}, progress={feedback.progress:.2f}'
        )


def main(args=None):
    rclpy.init(args=args)
    node = CycleCollectValidation()
    try:
        exit_code = node.run()
    finally:
        node.destroy_node()
        rclpy.shutdown()
    sys.exit(exit_code)
