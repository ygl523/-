# dishbot_tests

Acceptance and integration tests for the Dishbot simulation.

Stage 1 contains command entry points for the required tests. Later stages will connect these tests to Gazebo, Nav2, pusher motion, and table collection behavior.
